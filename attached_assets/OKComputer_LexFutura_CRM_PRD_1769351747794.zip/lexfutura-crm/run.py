#!/usr/bin/env python
"""
Script para executar o LexFutura CRM
"""

import os
from app import app, db, socketio
from config import config

def create_directories():
    """Cria diretórios necessários"""
    directories = [
        'uploads',
        'uploads/documents',
        'uploads/templates',
        'logs',
        'temp'
    ]
    
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)

if __name__ == '__main__':
    # Carregar configuração
    config_name = os.getenv('FLASK_CONFIG', 'development')
    app.config.from_object(config[config_name])
    
    # Criar diretórios
    create_directories()
    
    # Configurar banco de dados
    with app.app_context():
        db.create_all()
        
        # Criar usuário admin se não existir
        from models.user import User
        from werkzeug.security import generate_password_hash
        
        if not User.query.filter_by(email='admin@lexfutura.com').first():
            admin = User(
                name='Administrador',
                email='admin@lexfutura.com',
                password_hash=generate_password_hash('admin123'),
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print("Usuário admin criado: admin@lexfutura.com / admin123")
    
    # Executar aplicação
    print("=" * 60)
    print("LexFutura CRM - Sistema de Gestão Jurídica")
    print("=" * 60)
    print(f"Modo: {config_name}")
    print(f"Banco de dados: {app.config['SQLALCHEMY_DATABASE_URI']}")
    print(f"Debug: {app.config['DEBUG']}")
    print("=" * 60)
    print("Acesse: http://localhost:5000")
    print("Usuário: admin@lexfutura.com")
    print("Senha: admin123")
    print("=" * 60)
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=app.config['DEBUG'])