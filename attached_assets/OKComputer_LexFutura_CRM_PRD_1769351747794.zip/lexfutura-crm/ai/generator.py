"""
Módulo de Geração de Documentos por IA

Este módulo implementa a funcionalidade de geração de documentos jurídicos
utilizando modelos de linguagem (OpenAI GPT-4, GLM-4, etc.)
"""

import openai
import json
import re
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

@dataclass
class GenerationRequest:
    """Request para geração de documento"""
    gem_id: int
    title: str
    context: str
    variables: Dict[str, Any]
    persona_id: Optional[int] = None
    user_id: int = None

@dataclass
class GenerationResult:
    """Resultado da geração de documento"""
    success: bool
    content: str = ""
    error_message: str = ""
    tokens_used: int = 0
    model: str = ""
    generation_time: float = 0.0

class DocumentGenerator:
    """Gerador de documentos jurídicos por IA"""
    
    def __init__(self, api_key: str, model: str = "gpt-4"):
        """
        Inicializa o gerador
        
        Args:
            api_key: Chave da API OpenAI
            model: Modelo a ser utilizado (gpt-4, gpt-3.5-turbo, etc.)
        """
        openai.api_key = api_key
        self.model = model
        self.client = openai.OpenAI(api_key=api_key)
    
    def generate_document(self, request: GenerationRequest, 
                         template: str, 
                         instructions: str,
                         persona_style: Optional[Dict] = None) -> GenerationResult:
        """
        Gera um documento jurídico baseado no template e persona
        
        Args:
            request: Dados da requisição
            template: Template base do documento
            instructions: Instruções para a IA
            persona_style: Características de estilo da persona
            
        Returns:
            GenerationResult com o documento gerado
        """
        try:
            # Preparar o contexto para a IA
            context = self._build_context(request, template, instructions, persona_style)
            
            # Fazer a chamada para a API
            start_time = datetime.now()
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self._build_system_prompt(persona_style)},
                    {"role": "user", "content": context}
                ],
                temperature=0.7,
                max_tokens=4000,
                top_p=1.0,
                frequency_penalty=0.0,
                presence_penalty=0.0
            )
            
            end_time = datetime.now()
            generation_time = (end_time - start_time).total_seconds()
            
            # Extrair conteúdo gerado
            content = response.choices[0].message.content
            
            # Aplicar pós-processamento
            content = self._post_process(content, request.variables)
            
            return GenerationResult(
                success=True,
                content=content,
                tokens_used=response.usage.total_tokens,
                model=self.model,
                generation_time=generation_time
            )
            
        except Exception as e:
            return GenerationResult(
                success=False,
                error_message=str(e)
            )
    
    def _build_context(self, request: GenerationRequest, 
                      template: str, 
                      instructions: str,
                      persona_style: Optional[Dict]) -> str:
        """Constrói o contexto para enviar à IA"""
        
        context_parts = []
        
        # Instruções base
        context_parts.append("=" * 50)
        context_parts.append("INSTRUÇÕES")
        context_parts.append("=" * 50)
        context_parts.append(instructions)
        
        # Contexto do caso
        context_parts.append("\n" + "=" * 50)
        context_parts.append("CONTEXTO DO CASO")
        context_parts.append("=" * 50)
        context_parts.append(f"Título: {request.title}")
        context_parts.append(f"Contexto: {request.context}")
        
        # Variáveis
        if request.variables:
            context_parts.append("\n" + "=" * 50)
            context_parts.append("VARIÁVEIS")
            context_parts.append("=" * 50)
            for key, value in request.variables.items():
                context_parts.append(f"{key}: {value}")
        
        # Template
        context_parts.append("\n" + "=" * 50)
        context_parts.append("TEMPLATE BASE")
        context_parts.append("=" * 50)
        context_parts.append(template)
        
        # Estilo da persona (se disponível)
        if persona_style:
            context_parts.append("\n" + "=" * 50)
            context_parts.append("ESTILO DE ESCRITA")
            context_parts.append("=" * 50)
            if persona_style.get('formality_level'):
                context_parts.append(f"Nível de formalidade: {persona_style['formality_level']}")
            if persona_style.get('preferred_terms'):
                context_parts.append(f"Termos preferidos: {', '.join(persona_style['preferred_terms'])}")
            if persona_style.get('sentence_structure'):
                context_parts.append(f"Estrutura de frases: {persona_style['sentence_structure']}")
        
        return "\n".join(context_parts)
    
    def _build_system_prompt(self, persona_style: Optional[Dict]) -> str:
        """Constrói o prompt do sistema para a IA"""
        
        base_prompt = """Você é um assistente jurídico especializado em elaboração de peças processuais.
Suas respostas devem:

1. Seguir rigorosamente as normas jurídicas brasileiras
2. Utilizar linguagem técnica apropriada
3. Estruturar o documento de forma profissional
4. Manter coerência e coesão textual
5. Ser objetivo e direto, evitando prolixidade
"""
        
        if persona_style:
            base_prompt += "\nESTILO DE ESCRITA ADOTADO:\n"
            if persona_style.get('formality_level'):
                base_prompt += f"- Nível de formalidade: {persona_style['formality_level']}\n"
            if persona_style.get('sentence_structure'):
                base_prompt += f"- Estrutura de frases: {persona_style['sentence_structure']}\n"
            if persona_style.get('argumentation_style'):
                base_prompt += f"- Estilo argumentativo: {persona_style['argumentation_style']}\n"
            if persona_style.get('preferred_terms'):
                base_prompt += f"- Termos preferidos: {', '.join(persona_style['preferred_terms'])}\n"
        
        base_prompt += """

IMPORTANTE:
- Não inclua comentários ou explicações fora do documento
- Gere apenas o conteúdo do documento jurídico
- Use as variáveis fornecidas para personalizar o documento
- Mantenha a estrutura do template fornecido
"""
        
        return base_prompt
    
    def _post_process(self, content: str, variables: Dict[str, Any]) -> str:
        """Aplica pós-processamento ao documento gerado"""
        
        # Substituir placeholders que não foram preenchidos
        for key, value in variables.items():
            placeholder = f"{{{key}}}"
            content = content.replace(placeholder, str(value))
        
        # Limpar múltiplos espaços em branco
        content = re.sub(r'\s+', ' ', content)
        
        # Garantir quebras de linha apropriadas
        content = content.replace('\n\n\n', '\n\n')
        
        # Adicionar data atual se necessário
        if '[DATA_ATUAL]' in content:
            content = content.replace('[DATA_ATUAL]', datetime.now().strftime('%d de %B de %Y'))
        
        return content.strip()

class PersonaExtractor:
    """Extrai características de estilo de documentos jurídicos"""
    
    def __init__(self, api_key: str):
        """Inicializa o extrator de persona"""
        self.client = openai.OpenAI(api_key=api_key)
    
    def extract_features(self, documents: List[str]) -> Dict[str, Any]:
        """
        Extrai características de estilo de uma lista de documentos
        
        Args:
            documents: Lista de documentos jurídicos
            
        Returns:
            Dicionário com características extraídas
        """
        
        # Combinar documentos
        combined_text = "\n\n".join(documents)
        
        # Limitar tamanho para não exceder limite da API
        if len(combined_text) > 10000:
            combined_text = combined_text[:10000]
        
        prompt = f"""
Analise os seguintes documentos jurídicos e extraia as características de estilo do autor:

{combined_text}

Por favor, forneça a análise no seguinte formato JSON:

{{
    "formality_level": "formal|semi_formal|tecnico",
    "sentence_structure": "complexa|media|simples",
    "argumentation_style": "dedutivo|indutivo|misto",
    "preferred_terms": ["termo1", "termo2", "termo3"],
    "paragraph_length": "longo|medio|curto",
    "use_of_precedents": "frequente|moderado|raro",
    "citation_style": "completa|resumida|autor_data",
    "conclusion_approach": "objetivo|detalhado|persuasivo",
    "tone": "neutro|assertivo|diplomatico"
}}
"""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Você é um especialista em análise de estilo jurídico. Responda apenas com JSON válido."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1000
            )
            
            # Parse JSON response
            features = json.loads(response.choices[0].message.content)
            
            # Adicionar metadados
            features['extraction_date'] = datetime.now().isoformat()
            features['document_count'] = len(documents)
            features['total_characters'] = len(combined_text)
            
            return features
            
        except json.JSONDecodeError:
            # Se falhar ao parsear JSON, retornar estrutura básica
            return {
                "formality_level": "formal",
                "sentence_structure": "complexa",
                "argumentation_style": "dedutivo",
                "preferred_terms": [],
                "paragraph_length": "medio",
                "use_of_precedents": "moderado",
                "citation_style": "completa",
                "conclusion_approach": "objetivo",
                "tone": "neutro",
                "extraction_date": datetime.now().isoformat(),
                "document_count": len(documents),
                "total_characters": len(combined_text),
                "error": "Failed to extract detailed features"
            }
        
        except Exception as e:
            return {
                "error": str(e),
                "extraction_date": datetime.now().isoformat()
            }

# Funções auxiliares
def format_cpf_cnpj(document: str) -> str:
    """Formata CPF ou CNPJ"""
    doc = re.sub(r'[^\d]', '', document)
    
    if len(doc) == 11:
        # CPF
        return f"{doc[:3]}.{doc[3:6]}.{doc[6:9]}-{doc[9:]}"
    elif len(doc) == 14:
        # CNPJ
        return f"{doc[:2]}.{doc[2:5]}.{doc[5:8]}/{doc[8:12]}-{doc[12:]}"
    
    return document

def format_process_number(number: str) -> str:
    """Formata número do processo"""
    num = re.sub(r'[^\d]', '', number)
    
    if len(num) == 20:
        return f"{num[:7]}-{num[7:9]}.{num[9:13]}.{num[13]}.{num[14:16]}.{num[16:]}"
    
    return number

# Exportar classes principais
__all__ = ['DocumentGenerator', 'PersonaExtractor', 'GenerationRequest', 'GenerationResult']