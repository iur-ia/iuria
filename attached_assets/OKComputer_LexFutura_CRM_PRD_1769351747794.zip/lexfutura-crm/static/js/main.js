// ===== JavaScript Principal - LexFutura CRM =====

// Inicialização do Socket.IO
const socket = io();

// Conectar ao WebSocket
socket.on('connect', function() {
    console.log('Conectado ao servidor WebSocket');
});

// Receber notificações
socket.on('notification', function(data) {
    showNotification(data.message, data.type || 'info');
});

// ===== Utilidades =====

// Mostrar notificação toast
function showNotification(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container') || createToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remover após fechar
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

// Criar container de toasts
function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    container.style.zIndex = '9999';
    document.body.appendChild(container);
    return container;
}

// ===== Dashboard Functions =====

// Atualizar status da tarefa via AJAX
async function updateTaskStatus(taskId, newStatus) {
    try {
        const response = await fetch(`/api/tasks/${taskId}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ status: newStatus })
        });
        
        if (response.ok) {
            showNotification('Status da tarefa atualizado!', 'success');
            
            // Atualizar visual se necessário
            const taskElement = document.querySelector(`[data-task-id="${taskId}"]`);
            if (taskElement) {
                taskElement.className = taskElement.className.replace(/bg-\w+/, `bg-${getStatusColor(newStatus)}`);
            }
        } else {
            showNotification('Erro ao atualizar tarefa', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Erro de conexão', 'error');
    }
}

// Obter cor do status
function getStatusColor(status) {
    const colors = {
        'pendente': 'secondary',
        'em_andamento': 'warning',
        'concluida': 'success',
        'cancelada': 'danger'
    };
    return colors[status] || 'secondary';
}

// ===== Kanban Board Functions =====

// Permitir drag and drop no Kanban
function initializeKanban() {
    const columns = document.querySelectorAll('.kanban-column');
    const tasks = document.querySelectorAll('.kanban-task');
    
    // Adicionar event listeners para drag and drop
    tasks.forEach(task => {
        task.draggable = true;
        task.addEventListener('dragstart', handleDragStart);
        task.addEventListener('dragend', handleDragEnd);
    });
    
    columns.forEach(column => {
        column.addEventListener('dragover', handleDragOver);
        column.addEventListener('drop', handleDrop);
    });
}

let draggedTask = null;

function handleDragStart(e) {
    draggedTask = this;
    this.style.opacity = '0.5';
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/html', this.innerHTML);
}

function handleDragEnd(e) {
    this.style.opacity = '1';
    draggedTask = null;
}

function handleDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }
    e.dataTransfer.dropEffect = 'move';
    return false;
}

function handleDrop(e) {
    if (e.stopPropagation) {
        e.stopPropagation();
    }
    
    if (draggedTask) {
        const newStatus = this.dataset.status;
        const taskId = draggedTask.dataset.taskId;
        
        // Mover elemento visualmente
        this.querySelector('.kanban-tasks').appendChild(draggedTask);
        
        // Atualizar no servidor
        updateTaskStatus(taskId, newStatus);
    }
    
    return false;
}

// ===== AI Studio Functions =====

// Treinar persona com documentos
async function trainPersona(personaId, documents) {
    const formData = new FormData();
    formData.append('persona_id', personaId);
    
    for (let i = 0; i < documents.length; i++) {
        formData.append('documents', documents[i]);
    }
    
    try {
        const response = await fetch('/api/ai/train-persona', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            showNotification('Persona treinada com sucesso!', 'success');
            // Atualizar interface
        } else {
            showNotification('Erro ao treinar persona', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Erro de conexão', 'error');
    }
}

// Gerar documento com IA
async function generateDocument(gemId, data) {
    try {
        const response = await fetch('/api/ai/generate-document', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                gem_id: gemId,
                data: data
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            showNotification('Documento gerado com sucesso!', 'success');
            return result.document;
        } else {
            showNotification('Erro ao gerar documento', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Erro de conexão', 'error');
    }
}

// ===== Form Utilities =====

// Validar CPF/CNPJ
function validateDocument(document) {
    document = document.replace(/[^\d]/g, '');
    
    if (document.length === 11) {
        return validateCPF(document);
    } else if (document.length === 14) {
        return validateCNPJ(document);
    }
    
    return false;
}

function validateCPF(cpf) {
    if (cpf.length !== 11 || /^(.)\1{10}$/.test(cpf)) return false;
    
    let sum = 0;
    let remainder;
    
    for (let i = 1; i <= 9; i++) {
        sum += parseInt(cpf.substring(i - 1, i)) * (11 - i);
    }
    
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.substring(9, 10))) return false;
    
    sum = 0;
    for (let i = 1; i <= 10; i++) {
        sum += parseInt(cpf.substring(i - 1, i)) * (12 - i);
    }
    
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.substring(10, 11))) return false;
    
    return true;
}

function validateCNPJ(cnpj) {
    if (cnpj.length !== 14) return false;
    
    // Simplified CNPJ validation
    // In production, implement full validation algorithm
    return true;
}

// Format document input
function formatDocumentInput(input) {
    let value = input.value.replace(/[^\d]/g, '');
    
    if (value.length <= 11) {
        // CPF format
        value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    } else {
        // CNPJ format
        value = value.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    }
    
    input.value = value;
}

// Format phone input
function formatPhoneInput(input) {
    let value = input.value.replace(/[^\d]/g, '');
    
    if (value.length <= 10) {
        // Landline
        value = value.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    } else {
        // Mobile
        value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    
    input.value = value;
}

// ===== Search and Filter Functions =====

// Pesquisa dinâmica
function initializeSearch(inputId, containerId) {
    const input = document.getElementById(inputId);
    const container = document.getElementById(containerId);
    
    if (!input || !container) return;
    
    input.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const items = container.querySelectorAll('.searchable-item');
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            if (text.includes(searchTerm)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });
}

// ===== Theme Toggle =====
function toggleTheme() {
    const body = document.body;
    const themeIcon = document.querySelector('#themeToggle i');
    
    if (body.classList.contains('dark-theme')) {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
        themeIcon.className = 'bi bi-sun-fill';
        localStorage.setItem('theme', 'light');
    } else {
        body.classList.remove('light-theme');
        body.classList.add('dark-theme');
        themeIcon.className = 'bi bi-moon-fill';
        localStorage.setItem('theme', 'dark');
    }
}

// Load saved theme
function loadTheme() {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    const body = document.body;
    const themeIcon = document.querySelector('#themeToggle i');
    
    if (savedTheme === 'light') {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
        if (themeIcon) themeIcon.className = 'bi bi-sun-fill';
    } else {
        body.classList.remove('light-theme');
        body.classList.add('dark-theme');
        if (themeIcon) themeIcon.className = 'bi bi-moon-fill';
    }
}

// ===== Auto-save Functions =====

// Auto-save form data to localStorage
function enableAutoSave(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    const inputs = form.querySelectorAll('input, textarea, select');
    
    // Load saved data
    inputs.forEach(input => {
        const savedValue = localStorage.getItem(`autosave_${formId}_${input.name}`);
        if (savedValue && !input.value) {
            input.value = savedValue;
        }
    });
    
    // Save on change
    inputs.forEach(input => {
        input.addEventListener('change', function() {
            localStorage.setItem(`autosave_${formId}_${this.name}`, this.value);
        });
    });
}

// Clear auto-saved data
function clearAutoSave(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    const inputs = form.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        localStorage.removeItem(`autosave_${formId}_${input.name}`);
    });
}

// ===== Initialize on page load =====
document.addEventListener('DOMContentLoaded', function() {
    // Load theme
    loadTheme();
    
    // Theme toggle button
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
    
    // Initialize Kanban if present
    if (document.querySelector('.kanban-board')) {
        initializeKanban();
    }
    
    // Initialize search if present
    if (document.getElementById('searchInput')) {
        initializeSearch('searchInput', 'searchContainer');
    }
    
    // Auto-format inputs
    const documentInputs = document.querySelectorAll('input[data-format="document"]');
    documentInputs.forEach(input => {
        input.addEventListener('input', function() {
            formatDocumentInput(this);
        });
    });
    
    const phoneInputs = document.querySelectorAll('input[data-format="phone"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            formatPhoneInput(this);
        });
    });
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    console.log('LexFutura CRM - Sistema inicializado');
});