"""
Script de migração e inicialização do banco de dados
"""

import os
import sys
from app import app, db
from models.user import User
from models.client import Client
from models.lawsuit import Lawsuit
from models.task import Task
from models.progress import Progress
from models.persona import Persona
from models.gem import Gem
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random

def create_sample_data():
    """Cria dados de exemplo para demonstração"""
    
    print("Criando dados de exemplo...")
    
    # Criar usuário de teste
    test_user = User(
        name="Advogado Teste",
        email="teste@lexfutura.com",
        password_hash=generate_password_hash("teste123"),
        role="advogado"
    )
    db.session.add(test_user)
    db.session.flush()  # Para obter o ID
    
    # Criar clientes de exemplo
    clients = [
        Client(
            name="João da Silva",
            email="joao@email.com",
            phone="(11) 99999-9999",
            document="123.456.789-00",
            type="pessoa_fisica",
            user_id=test_user.id
        ),
        Client(
            name="Empresa XYZ Ltda",
            email="contato@xyz.com.br",
            phone="(11) 3333-3333",
            document="12.345.678/0001-90",
            type="pessoa_juridica",
            user_id=test_user.id
        ),
        Client(
            name="Maria Santos",
            email="maria@email.com",
            phone="(21) 98888-8888",
            document="987.654.321-00",
            type="pessoa_fisica",
            user_id=test_user.id
        )
    ]
    
    for client in clients:
        db.session.add(client)
    
    db.session.flush()
    
    # Criar processos de exemplo
    lawsuits = [
        Lawsuit(
            number="1234567-89.2023.8.26.0100",
            title="Ação Indenizatória por Danos Morais",
            court="TJSP",
            court_section="1ª Vara Cível",
            nature="Direito Civil",
            subject="Indenização por Danos Morais",
            status="ativo",
            phase="Contestação",
            priority="alta",
            deadline_date=datetime.now() + timedelta(days=15),
            hearing_date=datetime.now() + timedelta(days=30),
            value=50000.00,
            client_id=clients[0].id,
            user_id=test_user.id
        ),
        Lawsuit(
            number="7654321-98.2023.5.01.0001",
            title="Execução de Título Extrajudicial",
            court="TRF1",
            court_section="Seção Judiciária de SP",
            nature="Direito Processual Civil",
            subject="Execução de Título Extrajudicial",
            status="ativo",
            phase="Cumprimento de Sentença",
            priority="normal",
            deadline_date=datetime.now() + timedelta(days=45),
            value=125000.00,
            client_id=clients[1].id,
            user_id=test_user.id
        ),
        Lawsuit(
            number="1112223-44.2023.8.26.0200",
            title="Ação Rescisória Contratual",
            court="TJSP",
            court_section="2ª Vara Cível",
            nature="Direito Contratual",
            subject="Rescisão Contratual",
            status="ativo",
            phase="Instrução",
            priority="urgente",
            deadline_date=datetime.now() + timedelta(days=5),
            value=25000.00,
            client_id=clients[2].id,
            user_id=test_user.id
        )
    ]
    
    for lawsuit in lawsuits:
        db.session.add(lawsuit)
    
    db.session.flush()
    
    # Criar tarefas de exemplo
    tasks = [
        Task(
            title="Elaborar Contestação",
            description="Preparar contestação com base nos documentos anexados",
            status="em_andamento",
            priority="alta",
            due_date=datetime.now() + timedelta(days=10),
            lawsuit_id=lawsuits[0].id,
            user_id=test_user.id
        ),
        Task(
            title="Protocolar Petição Inicial",
            description="Protocolar petição inicial no fórum",
            status="pendente",
            priority="normal",
            due_date=datetime.now() + timedelta(days=5),
            lawsuit_id=lawsuits[2].id,
            user_id=test_user.id
        ),
        Task(
            title="Analisar Documentos",
            description="Analisar documentos do processo",
            status="concluida",
            priority="normal",
            due_date=datetime.now() - timedelta(days=2),
            lawsuit_id=lawsuits[1].id,
            user_id=test_user.id,
            completed_at=datetime.now() - timedelta(days=1)
        )
    ]
    
    for task in tasks:
        db.session.add(task)
    
    db.session.flush()
    
    # Criar andamentos de exemplo
    progresses = [
        Progress(
            date=datetime.now() - timedelta(days=10),
            description="Petição inicial protocolada",
            type="protocolo",
            importance="normal",
            lawsuit_id=lawsuits[0].id,
            source="manual"
        ),
        Progress(
            date=datetime.now() - timedelta(days=5),
            description="Citação expedida",
            type="citacao",
            importance="alta",
            lawsuit_id=lawsuits[0].id,
            source="manual"
        ),
        Progress(
            date=datetime.now() - timedelta(days=1),
            description="Contestação apresentada",
            type="contestacao",
            importance="alta",
            lawsuit_id=lawsuits[2].id,
            source="manual"
        )
    ]
    
    for progress in progresses:
        db.session.add(progress)
    
    # Criar persona de exemplo
    persona = Persona(
        name="Meu Estilo Jurídico",
        description="Persona baseada no meu estilo de escrita jurídica",
        style_features={
            "formality_level": "formal",
            "sentence_structure": "complexa",
            "argumentation_style": "dedutivo",
            "preferred_terms": ["direito", "lei", "artigo"],
            "paragraph_length": "longo"
        },
        status="trained",
        training_date=datetime.now(),
        user_id=test_user.id
    )
    db.session.add(persona)
    
    db.session.flush()
    
    # Criar gems de exemplo
    gems = [
        Gem(
            name="Contestação Padrão",
            description="Template de contestação para ações indenizatórias",
            document_type="contestacao",
            template="Preâmbulo: [PREAMBULO]\n\nCONTESTAÇÃO\n\n[CONTEUDO]\n\nPostulação: [POSTULACAO]",
            instructions="Elabore uma contestação formal respondendo à petição inicial",
            variables=[
                {"name": "PREAMBULO", "label": "Preâmbulo", "type": "text"},
                {"name": "CONTEUDO", "label": "Conteúdo", "type": "textarea"},
                {"name": "POSTULACAO", "label": "Postulação", "type": "textarea"}
            ],
            status="active",
            user_id=test_user.id,
            persona_id=persona.id
        ),
        Gem(
            name="Petição Inicial",
            description="Template de petição inicial",
            document_type="peticao_inicial",
            template="EXCELENTÍSSIMO SENHOR DOUTOR JUIZ\n\n[PARTE_AUTORA], por seus procuradores infra-assinados, vem respeitosamente à presença de Vossa Excelência propor [ACAO]",
            instructions="Elabore uma petição inicial completa",
            variables=[
                {"name": "PARTE_AUTORA", "label": "Parte Autora", "type": "text"},
                {"name": "ACAO", "label": "Tipo de Ação", "type": "text"}
            ],
            status="active",
            user_id=test_user.id
        )
    ]
    
    for gem in gems:
        db.session.add(gem)
    
    # Commit final
    db.session.commit()
    
    print("✓ Dados de exemplo criados com sucesso!")
    print(f"  - Usuário: teste@lexfutura.com / teste123")
    print(f"  - Clientes: {len(clients)}")
    print(f"  - Processos: {len(lawsuits)}")
    print(f"  - Tarefas: {len(tasks)}")
    print(f"  - Personas: 1")
    print(f"  - Gems: {len(gems)}")

def reset_database():
    """Reinicia o banco de dados"""
    print("Reiniciando banco de dados...")
    
    # Dropar todas as tabelas
    db.drop_all()
    
    # Criar tabelas
    db.create_all()
    
    print("✓ Banco de dados reiniciado!")

def main():
    """Função principal"""
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == 'reset':
            reset_database()
            create_sample_data()
        elif command == 'init':
            with app.app_context():
                db.create_all()
                create_sample_data()
        elif command == 'create-admin':
            with app.app_context():
                admin = User(
                    name='Administrador',
                    email='admin@lexfutura.com',
                    password_hash=generate_password_hash('admin123'),
                    role='admin'
                )
                db.session.add(admin)
                db.session.commit()
                print("✓ Usuário admin criido: admin@lexfutura.com / admin123")
        else:
            print("Comando não reconhecido. Use: reset, init, create-admin")
    else:
        print("Uso: python migrations.py [comando]")
        print("Comandos:")
        print("  reset      - Reinicia o banco e cria dados de exemplo")
        print("  init       - Inicializa com dados de exemplo")
        print("  create-admin - Cria usuário admin")

if __name__ == '__main__':
    main()