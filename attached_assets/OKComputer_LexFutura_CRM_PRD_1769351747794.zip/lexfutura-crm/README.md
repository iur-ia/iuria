# LexFutura CRM

Sistema de Gestão Jurídica de Próxima Geração

## 🚀 Visão Geral

O LexFutura CRM é uma plataforma inovadora desenvolvida para transformar a maneira como escritórios de advocacia e departamentos jurídicos empresariais gerenciam seus processos, clientes e documentos.

## ✨ Características Principais

- **Design Futurista**: Interface moderna com glassmorphism e modo escuro
- **Inteligência Artificial**: Geração de documentos com aprendizado de estilo pessoal
- **Monitoramento Tribunalício**: Scraping automático de andamentos processuais
- **Gestão Kanban**: Visualização de tarefas em formato Kanban
- **CRM Jurídico**: Gerenciamento completo de clientes e processos

## 🛠️ Tecnologias Utilizadas

- **Backend**: Python 3.8+, Flask, SQLAlchemy
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Banco de Dados**: SQLite (desenvolvimento), PostgreSQL (produção)
- **IA**: OpenAI GPT-4, GLM-4.7
- **Real-time**: Socket.IO, WebSockets

## 📋 Requisitos

- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)
- Chrome/Chromium (para scraping)

## 🔧 Instalação

### 1. Clone o repositório

```bash
git clone https://github.com/seu-usuario/lexfutura-crm.git
cd lexfutura-crm
```

### 2. Crie um ambiente virtual

```bash
python -m venv venv
```

### 3. Ative o ambiente virtual

**Linux/Mac:**
```bash
source venv/bin/activate
```

**Windows:**
```bash
venv\Scripts\activate
```

### 4. Instale as dependências

```bash
pip install -r requirements.txt
```

### 5. Configure Playwright (para scraping moderno)

```bash
# Opção automática (recomendado)
python setup_playwright.py

# Ou manualmente:
pip install playwright
playwright install chromium
```

### 6. Configure as variáveis de ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
SECRET_KEY=sua-chave-secreta-aqui
DATABASE_URL=sqlite:///lexfutura.db
OPENAI_API_KEY=sua-chave-openai-aqui
REDIS_URL=redis://localhost:6379/0
FLASK_ENV=development
FLASK_DEBUG=True
```

### 6. Execute testes

```bash
# Testar instalação
python test_install.py

# Testar scraping (opcional)
python test_scraping.py
```

### 7. Execute o sistema

```bash
python run.py
```

### 8. Acesse o sistema

Abra seu navegador e acesse: `http://localhost:5000`

**Credenciais de teste:**
- Email: `admin@lexfutura.com`
- Senha: `admin123`

## 📁 Estrutura do Projeto

```
lexfutura-crm/
├── app.py              # Aplicação Flask principal
├── config.py           # Configurações
├── run.py              # Script de execução
├── models/             # Modelos de dados
├── templates/          # Templates HTML
├── static/             # Arquivos estáticos (CSS, JS, imagens)
├── ai/                 # Módulo de Inteligência Artificial
├── scraping/           # Módulo de Scraping Tribunalício
├── utils/              # Utilidades
├── uploads/            # Arquivos enviados
├── requirements.txt    # Dependências
└── README.md          # Documentação
```

## 🎯 Funcionalidades

### Dashboard
- Visão geral de processos, clientes e tarefas
- Alertas de prazos próximos
- Estatísticas em tempo real

### Gestão de Processos
- Cadastro completo de processos
- Visualização por status e prioridade
- Histórico de andamentos

### Gestão de Clientes
- Cadastro de clientes (PF e PJ)
- Vinculação a processos
- Histórico de atendimentos

### Tarefas (Kanban)
- Visualização em formato Kanban
- Drag & drop para alterar status
- Priorização e prazos

### AI Studio
- Treinamento de personas
- Geração de documentos
- Templates configuráveis (Gems)

### Monitoramento Tribunalício
- **Playwright** como engine principal (mais rápido e confiável)
- **Selenium** como fallback (compatibilidade)
- Scraping automático de andamentos
- Notificações de movimentações
- Suporte a múltiplos tribunais: TJSP, TRF, STF
- Classificação de importância
- Rate limiting e cache
- Screenshots para debug
- Extração de capas de processos

## 🔐 Segurança

- Criptografia de senhas com bcrypt
- Proteção CSRF
- Validação de entrada de dados
- Sistema de autenticação e autorização

## 📊 Performance

- Rate limiting para scraping
- Cache de resultados
- Lazy loading
- Otimização de queries

## 🚀 Deploy

### Deploy no Railway

1. Conecte seu repositório ao Railway
2. Configure as variáveis de ambiente
3. Deploy automático a cada push

### Deploy manual com Gunicorn

```bash
gunicorn --worker-class eventlet -w 1 app:app --bind 0.0.0.0:5000
```

## 🔧 Configuração de Produção

### Variáveis de ambiente necessárias

```env
SECRET_KEY=your-super-secret-key
DATABASE_URL=postgresql://user:password@host/database
OPENAI_API_KEY=your-openai-api-key
REDIS_URL=redis://localhost:6379/0
FLASK_ENV=production
FLASK_DEBUG=False
```

### Banco de dados PostgreSQL

```bash
# Criar banco de dados
createdb lexfutura_db

# Configurar URI
DATABASE_URL=postgresql://username:password@localhost/lexfutura_db
```

## 📚 Documentação da API

### Autenticação

```http
POST /login
Content-Type: application/json

{
    "email": "user@example.com",
    "password": "password"
}
```

### Processos

```http
GET /api/processos
POST /api/processos
GET /api/processos/{id}
PUT /api/processos/{id}
DELETE /api/processos/{id}
```

### Clientes

```http
GET /api/clientes
POST /api/clientes
GET /api/clientes/{id}
PUT /api/clientes/{id}
DELETE /api/clientes/{id}
```

### Tarefas

```http
GET /api/tarefas
POST /api/tarefas
PUT /api/tarefas/{id}/status
```

### IA

```http
POST /api/ai/train-persona
POST /api/ai/generate-document
GET /api/ai/personas
GET /api/ai/gems
```

## 🧪 Testes

```bash
# Executar testes
python -m pytest

# Testes com cobertura
python -m pytest --cov=app
```

## 🔧 Troubleshooting - Playwright

### Problemas comuns:

**1. Erro "playwright: command not found"**
```bash
pip install playwright
playwright install chromium
```

**2. Erro "Browser not found"**
```bash
# Instalar navegadores
playwright install chromium
playwright install firefox

# Ou instalar todas as dependências do sistema:
# Ubuntu/Debian:
sudo apt install libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 \
                 libcups2 libdrm2 libxkbcommon0 libxcomposite1 \
                 libxdamage1 libxrandr2 libgbm1 libgtk-3-0 libasound2

# CentOS/RHEL:
sudo yum install atk cups-libs dbus-libs gdk-pixbuf2 gtk3 \
                 libXcomposite libXcursor libXdamage libXext \
                 libXi libXtst pango xorg-x11-server-Xvfb
```

**3. Erro de permissão (Linux/Mac)**
```bash
sudo playwright install-deps
```

**4. Conflito com Selenium**
```bash
# Desinstalar Selenium se não precisar:
pip uninstall selenium

# Ou use ambiente virtual separado
```

**5. Erro de conexão/firewall**
- Verifique configurações de firewall/antivírus
- Teste com VPN se necessário
- Configure proxy se necessário

**6. Servidor sem interface gráfica**
```bash
# Playwright já usa --headless por padrão
# Mas pode precisar de dependências adicionais:

# Ubuntu/Debian:
sudo apt install libnss3 libnspr4 libatk1.0-0 libcups2 \
                 libdrm2 libxkbcommon0 libxcomposite1 \
                 libxdamage1 libxrandr2 libgbm1 libgtk-3-0

# Verificar dependências faltantes:
playwright install-deps
```

### Scripts de ajuda:

```bash
# Verificar instalação
python setup_playwright.py

# Testar scraping
python test_scraping.py

# Verificar navegadores instalados
playwright show-browsers
```

### Fallback para Selenium:

Se Playwright não funcionar, o sistema automaticamente usará Selenium como fallback.

## 🐛 Reportando Bugs

Para reportar bugs, crie uma issue no GitHub com:
- Descrição detalhada do problema
- Passos para reproduzir
- Screenshots (se aplicável)
- Logs de erro

## 🤝 Contribuindo

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 👥 Autores

- **LexFutura Development Team** - Desenvolvimento inicial

## 📞 Suporte

Para suporte, envie um email para: suporte@lexfutura.com

## 🙏 Agradecimentos

- A todos os advogados que contribuíram com feedback
- À comunidade open source
- Aos desenvolvedores de bibliotecas utilizadas

---

Desenvolvido com ❤️ pela LexFutura Development Team