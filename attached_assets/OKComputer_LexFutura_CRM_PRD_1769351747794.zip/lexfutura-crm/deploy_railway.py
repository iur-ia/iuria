#!/usr/bin/env python
"""
Deploy para Railway - LexFutura CRM

Este script prepara o projeto para deploy no Railway.
"""

import os
import json

def create_railway_config():
    """Cria configuração para Railway"""
    
    # Criar railway.toml
    railway_config = """
[build]
cmd = "pip install -r requirements.txt && playwright install chromium"

[deploy]
startCommand = "python run.py"
healthcheckPath = "/"
healthcheckTimeout = 300
restartPolicyType = "ON_FAILURE"
"""
    
    with open('railway.toml', 'w') as f:
        f.write(railway_config.strip())
    
    print("✅ railway.toml criado")

def create_procfile():
    """Cria Procfile para Heroku/Railway"""
    procfile_content = """web: python run.py
"""
    
    with open('Procfile', 'w') as f:
        f.write(procfile_content)
    
    print("✅ Procfile criado")

def update_requirements():
    """Atualiza requirements para produção"""
    with open('requirements.txt', 'r') as f:
        content = f.read()
    
    # Adicionar gunicorn se não estiver
    if 'gunicorn' not in content:
        content += "\ngunicorn==21.2.0\n"
    
    with open('requirements.txt', 'w') as f:
        f.write(content)
    
    print("✅ Requirements atualizado")

def create_runtime_txt():
    """Cria runtime.txt para Python version"""
    with open('runtime.txt', 'w') as f:
        f.write('python-3.9.18\n')
    
    print("✅ runtime.txt criado")

def update_env_example():
    """Atualiza .env.example para produção"""
    env_content = """# LexFutura CRM - Configurações

# Segurança
SECRET_KEY=change-this-in-production-to-a-random-string

# Banco de Dados
# Para Railway, use a variável DATABASE_URL fornecida
DATABASE_URL=sqlite:///lexfutura.db

# OpenAI (opcional para IA)
OPENAI_API_KEY=your-openai-api-key

# Redis (opcional para cache)
REDIS_URL=redis://localhost:6379/0

# Ambiente
FLASK_ENV=production
FLASK_DEBUG=False

# Porta (Railway define automaticamente)
PORT=5000
"""
    
    with open('.env.example', 'w') as f:
        f.write(env_content)
    
    print("✅ .env.example atualizado")

def create_app_json():
    """Cria app.json para Heroku/Railway"""
    app_json = {
        "name": "LexFutura CRM",
        "description": "Sistema de Gestão Jurídica de Próxima Geração",
        "keywords": ["flask", "python", "crm", "legal", "playwright"],
        "website": "https://github.com/seu-usuario/lexfutura-crm",
        "repository": "https://github.com/seu-usuario/lexfutura-crm",
        "success_url": "/",
        "env": {
            "SECRET_KEY": {
                "description": "Chave secreta para Flask",
                "generator": "secret"
            },
            "FLASK_ENV": {
                "description": "Ambiente Flask",
                "value": "production"
            }
        },
        "buildpacks": [
            {
                "url": "heroku/python"
            }
        ]
    }
    
    with open('app.json', 'w') as f:
        json.dump(app_json, f, indent=2)
    
    print("✅ app.json criado")

def update_procfile():
    """Atualiza Procfile para gunicorn em produção"""
    procfile_content = """web: gunicorn --worker-class eventlet -w 1 app:app --bind 0.0.0.0:$PORT
"""
    
    with open('Procfile', 'w') as f:
        f.write(procfile_content)
    
    print("✅ Procfile atualizado para produção")

def create_docker_compose():
    """Cria docker-compose.yml para desenvolvimento local"""
    docker_compose = """version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=development
      - FLASK_DEBUG=True
      - DATABASE_URL=sqlite:///lexfutura.db
    volumes:
      - ./uploads:/app/uploads
      - ./logs:/app/logs
    restart: unless-stopped

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    restart: unless-stopped
"""
    
    with open('docker-compose.yml', 'w') as f:
        f.write(docker_compose)
    
    print("✅ docker-compose.yml criado")

def create_deploy_scripts():
    """Cria scripts de deploy"""
    
    # Script para Railway CLI
    deploy_sh = """#!/bin/bash
# Deploy para Railway

echo "🚀 Fazendo deploy para Railway..."

# Verificar se Railway CLI está instalado
if ! command -v railway &> /dev/null
then
    echo "❌ Railway CLI não encontrado"
    echo "Instale com: npm install -g @railway/cli"
    exit 1
fi

# Login se necessário
echo "📋 Verificando login no Railway..."
railway whoami

if [ $? -ne 0 ]; then
    echo "🔐 Faça login no Railway..."
    railway login
fi

# Deploy
railway up

echo "✅ Deploy concluído!"
echo "🌐 Acesse: $(railway domain)"
"""
    
    with open('deploy.sh', 'w') as f:
        f.write(deploy_sh)
    
    os.chmod('deploy.sh', 0o755)
    
    print("✅ deploy.sh criado")

def show_instructions():
    """Mostra instruções de deploy"""
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║           🚀 DEPLOY CONFIGURADO COM SUCESSO!                 ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝

📋 OPÇÕES DE DEPLOY:

1. RAILWAY (Recomendado - Gratuito):
   
   # Opção A - CLI (Mais fácil)
   npm install -g @railway/cli
   railway login
   railway init
   railway up
   
   # Opção B - Dashboard
   - Acesse: https://railway.app
   - Crie novo projeto
   - Conecte seu GitHub
   - Deploy automático!

2. RENDER:
   
   - Acesse: https://render.com
   - New > Web Service
   - Conecte GitHub
   - Configure: Python 3.9
   - Build Command: pip install -r requirements.txt && playwright install chromium
   - Start Command: python run.py
   - Deploy!

3. HEROKU:
   
   # Instalar Heroku CLI
   curl https://cli-assets.heroku.com/install.sh | sh
   heroku login
   
   # Criar app
   heroku create seu-app-lexfutura
   heroku buildpacks:set heroku/python
   
   # Configurar buildpack do Playwright
   heroku buildpacks:add https://github.com/mxschmitt/heroku-playwright-buildpack
   
   # Deploy
   git push heroku main

4. DOCKER (Qualquer servidor):
   
   # Build
   docker build -t lexfutura-crm .
   
   # Run
   docker run -p 5000:5000 \
              -e SECRET_KEY=your-secret \
              -e DATABASE_URL=your-db-url \
              lexfutura-crm
   
   # Ou com docker-compose
   docker-compose up

5. VPS (Ubuntu/Debian):
   
   # Copiar projeto
   scp -r . user@vps:/opt/lexfutura-crm
   
   # No servidor
   cd /opt/lexfutura-crm
   ./quick_start.py

📋 ARQUIVOS CRIADOS:
- railway.toml
- Procfile
- app.json
- Dockerfile
- docker-compose.yml
- deploy.sh
- .env.example (atualizado)

🔧 VARIÁVEIS DE AMBIENTE NECESSÁRIAS:
- SECRET_KEY (gerada automaticamente no Railway)
- DATABASE_URL (PostgreSQL - Railway fornece)
- OPENAI_API_KEY (opcional para IA)
- PORT (definido automaticamente)

💡 DICAS:
- Railway: 500 horas/mês gratuitas
- Render: Plano free disponível
- Heroku: Free tier descontinuado
- Docker: Mais controle, mas requer servidor

🆘 SUPORTE:
- Railway Docs: docs.railway.app
- Render Docs: render.com/docs
- Heroku Docs: devcenter.heroku.com
""")

if __name__ == '__main__':
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║           🚀 CONFIGURADOR DE DEPLOY - LexFutura CRM          ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    print("\nPreparando projeto para deploy em serviços de cloud...\n")
    
    steps = [
        (create_railway_config, "Criando railway.toml"),
        (update_procfile, "Atualizando Procfile"),
        (create_runtime_txt, "Criando runtime.txt"),
        (update_env_example, "Atualizando .env.example"),
        (create_app_json, "Criando app.json"),
        (create_docker_compose, "Criando docker-compose.yml"),
        (create_deploy_scripts, "Criando scripts de deploy"),
    ]
    
    for step_func, step_name in steps:
        try:
            step_func()
        except Exception as e:
            print(f"⚠️  Erro em {step_name}: {e}")
    
    show_instructions()
    
    print("\n" + "="*60)
    print("✅ Configuração concluída!")
    print("="*60)
    print("\nEscolha uma opção de deploy acima e siga as instruções.")
    print("Boa sorte! 🚀")