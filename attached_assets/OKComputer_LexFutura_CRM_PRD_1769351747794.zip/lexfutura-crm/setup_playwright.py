#!/usr/bin/env python
"""
Script de setup para Playwright - LexFutura CRM

Este script instala e configura o Playwright para scraping.
"""

import subprocess
import sys
import os

def install_playwright():
    """Instala o Playwright e os navegadores necessários"""
    print("=" * 60)
    print("Setup do Playwright para LexFutura CRM")
    print("=" * 60)
    
    try:
        # Verificar se playwright está instalado
        print("\n1. Verificando instalação do Playwright...")
        result = subprocess.run([sys.executable, "-m", "playwright", "--version"], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✓ Playwright já instalado: {result.stdout.strip()}")
        else:
            print("⚠ Playwright não encontrado. Instalando...")
            subprocess.run([sys.executable, "-m", "pip", "install", "playwright"], check=True)
            print("✓ Playwright instalado com sucesso!")
        
        # Instalar navegadores
        print("\n2. Instalando navegadores...")
        print("Isso pode levar alguns minutos...")
        
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
        print("✓ Navegador Chromium instalado!")
        
        subprocess.run([sys.executable, "-m", "playwright", "install", "firefox"], check=True)
        print("✓ Navegador Firefox instalado!")
        
        # Testar importação
        print("\n3. Testando importação...")
        try:
            from playwright.sync_api import sync_playwright
            print("✓ Playwright importado com sucesso!")
        except ImportError as e:
            print(f"✗ Erro ao importar Playwright: {e}")
            return False
        
        print("\n" + "=" * 60)
        print("✅ Setup concluído com sucesso!")
        print("=" * 60)
        print("\nPlaywright está pronto para uso no scraping.")
        print("O sistema usará Playwright automaticamente quando disponível.")
        print("\nPara testar o scraping, execute:")
        print("  python test_scraping.py")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Erro durante a instalação: {e}")
        print("\nTente instalar manualmente:")
        print("  pip install playwright")
        print("  playwright install chromium")
        return False
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        return False

def test_playwright():
    """Testa se o Playwright está funcionando corretamente"""
    print("\n" + "=" * 60)
    print("Testando Playwright")
    print("=" * 60)
    
    try:
        from playwright.sync_api import sync_playwright
        
        print("\n✓ Playwright importado com sucesso")
        print("\nIniciando navegador de teste...")
        
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            
            # Testar acesso a página simples
            print("Acessando página de teste...")
            page.goto('https://httpbin.org/get', wait_until='networkidle', timeout=10000)
            
            # Verificar se carregou
            if page.content():
                print("✓ Navegador carregou página com sucesso")
            else:
                print("✗ Navegador não conseguiu carregar página")
                return False
            
            # Tirar screenshot de teste
            screenshot_path = "playwright_test.png"
            page.screenshot(path=screenshot_path)
            print(f"✓ Screenshot salva em: {screenshot_path}")
            
            browser.close()
        
        print("\n✅ Teste concluído com sucesso!")
        return True
        
    except Exception as e:
        print(f"\n❌ Erro no teste: {e}")
        print("\nPossíveis causas:")
        print("  - Navegador não instalado corretamente")
        print("  - Problemas de permissão")
        print("  - Conflito com Selenium")
        return False

def show_troubleshooting():
    """Mostra dicas de solução de problemas"""
    print("\n" + "=" * 60)
    print("Solução de Problemas")
    print("=" * 60)
    
    print("""
Problemas comuns e soluções:

1. Erro "playwright: command not found"
   → Execute: pip install playwright

2. Erro "Browser not found"
   → Execute: playwright install chromium

3. Erro de permissão no Linux/Mac
   → Execute: sudo playwright install-deps

4. Conflito com Selenium
   → Desinstale Selenium: pip uninstall selenium
   → Ou use ambiente virtual separado

5. Erro de conexão
   → Verifique firewall/antivírus
   → Teste com VPN se necessário

6. Erro no servidor (sem interface gráfica)
   → Use --headless mode (já configurado)
   → Instale dependências do sistema:
     Ubuntu/Debian: sudo apt install libnss3 libnspr4
     CentOS/RHEL: sudo yum install atk cups-libs

Para mais ajuda: https://playwright.dev/python/docs/intro
""")

if __name__ == '__main__':
    print("Playwright Setup - LexFutura CRM")
    print("=" * 60)
    
    # Verificar se está em ambiente virtual
    if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
        print("✓ Ambiente virtual detectado")
    else:
        print("⚠ Não está em ambiente virtual (recomendado)")
    
    # Instalar Playwright
    success = install_playwright()
    
    if success:
        # Testar
        test_playwright()
        
        print("\n" + "=" * 60)
        print("Próximos passos:")
        print("=" * 60)
        print("1. Execute: python run.py")
        print("2. Acesse: http://localhost:5000")
        print("3. Teste o scraping em: AI Studio > Monitoramento")
    else:
        show_troubleshooting()
        
        print("\n" + "=" * 60)
        print("Se o problema persistir:")
        print("=" * 60)
        print("1. Crie uma issue no GitHub")
        print("2. Ou entre em contato: suporte@lexfutura.com")
        print("3. Use Selenium como fallback (já implementado)")