"""
Rotas da API - LexFutura CRM

Este módulo define as rotas da API RESTful para o sistema.
"""

from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from models import db, User, Client, Lawsuit, Task, Progress, Persona, Gem
from ai.generator import DocumentGenerator, PersonaExtractor, GenerationRequest, GenerationResult
from scraping.courts import CourtScraperManager
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os
from datetime import datetime, timedelta

# Criar blueprint da API
api = Blueprint('api', __name__, url_prefix='/api')

# Inicializar gerenciadores
court_manager = CourtScraperManager()

# ===== ROTAS DE AUTENTICAÇÃO =====

@api.route('/auth/login', methods=['POST'])
def api_login():
    """Login via API"""
    data = request.get_json()
    
    if not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Email e senha são obrigatórios'}), 400
    
    user = User.query.filter_by(email=data['email']).first()
    
    if user and check_password_hash(user.password_hash, data['password']):
        # Em produção, implementar JWT ou token
        return jsonify({
            'success': True,
            'user': {
                'id': user.id,
                'name': user.name,
                'email': user.email,
                'role': user.role
            }
        })
    
    return jsonify({'error': 'Credenciais inválidas'}), 401

@api.route('/auth/logout', methods=['POST'])
@login_required
def api_logout():
    """Logout via API"""
    # Em produção, invalidar token
    return jsonify({'success': True})

# ===== ROTAS DE CLIENTES =====

@api.route('/clientes', methods=['GET'])
@login_required
def get_clients():
    """Lista todos os clientes do usuário"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    clients = Client.query.filter_by(user_id=current_user.id).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'clients': [client.to_dict() for client in clients.items],
        'pagination': {
            'page': clients.page,
            'pages': clients.pages,
            'total': clients.total,
            'per_page': clients.per_page
        }
    })

@api.route('/clientes', methods=['POST'])
@login_required
def create_client():
    """Cria um novo cliente"""
    data = request.get_json()
    
    # Validar dados
    if not data.get('name'):
        return jsonify({'error': 'Nome é obrigatório'}), 400
    
    client = Client(
        name=data['name'],
        email=data.get('email'),
        phone=data.get('phone'),
        document=data.get('document'),
        address=data.get('address'),
        type=data.get('type', 'pessoa_fisica'),
        notes=data.get('notes'),
        user_id=current_user.id
    )
    
    db.session.add(client)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'client': client.to_dict()
    }), 201

@api.route('/clientes/<int:client_id>', methods=['GET'])
@login_required
def get_client(client_id):
    """Obtém um cliente específico"""
    client = Client.query.get_or_404(client_id)
    
    if client.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    return jsonify(client.to_dict())

@api.route('/clientes/<int:client_id>', methods=['PUT'])
@login_required
def update_client(client_id):
    """Atualiza um cliente"""
    client = Client.query.get_or_404(client_id)
    
    if client.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    data = request.get_json()
    
    # Atualizar campos
    for field in ['name', 'email', 'phone', 'document', 'address', 'notes']:
        if field in data:
            setattr(client, field, data[field])
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'client': client.to_dict()
    })

@api.route('/clientes/<int:client_id>', methods=['DELETE'])
@login_required
def delete_client(client_id):
    """Exclui um cliente"""
    client = Client.query.get_or_404(client_id)
    
    if client.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    db.session.delete(client)
    db.session.commit()
    
    return jsonify({'success': True})

# ===== ROTAS DE PROCESSOS =====

@api.route('/processos', methods=['GET'])
@login_required
def get_lawsuits():
    """Lista todos os processos do usuário"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    
    query = Lawsuit.query.filter_by(user_id=current_user.id)
    
    if status:
        query = query.filter_by(status=status)
    
    lawsuits = query.order_by(Lawsuit.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'lawsuits': [lawsuit.to_dict() for lawsuit in lawsuits.items],
        'pagination': {
            'page': lawsuits.page,
            'pages': lawsuits.pages,
            'total': lawsuits.total,
            'per_page': lawsuits.per_page
        }
    })

@api.route('/processos', methods=['POST'])
@login_required
def create_lawsuit():
    """Cria um novo processo"""
    data = request.get_json()
    
    # Validar dados obrigatórios
    if not data.get('number') or not data.get('title') or not data.get('client_id'):
        return jsonify({'error': 'Número, título e cliente são obrigatórios'}), 400
    
    # Verificar se cliente existe e pertence ao usuário
    client = Client.query.get(data['client_id'])
    if not client or client.user_id != current_user.id:
        return jsonify({'error': 'Cliente inválido ou não autorizado'}), 400
    
    lawsuit = Lawsuit(
        number=data['number'],
        title=data['title'],
        court=data.get('court'),
        court_section=data.get('court_section'),
        nature=data.get('nature'),
        subject=data.get('subject'),
        status=data.get('status', 'ativo'),
        phase=data.get('phase'),
        priority=data.get('priority', 'normal'),
        value=data.get('value'),
        client_id=data['client_id'],
        user_id=current_user.id
    )
    
    # Definir datas
    if data.get('deadline_date'):
        lawsuit.deadline_date = datetime.strptime(data['deadline_date'], '%Y-%m-%d')
    if data.get('hearing_date'):
        lawsuit.hearing_date = datetime.strptime(data['hearing_date'], '%Y-%m-%d')
    
    db.session.add(lawsuit)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'lawsuit': lawsuit.to_dict()
    }), 201

@api.route('/processos/<int:lawsuit_id>', methods=['GET'])
@login_required
def get_lawsuit(lawsuit_id):
    """Obtém um processo específico"""
    lawsuit = Lawsuit.query.get_or_404(lawsuit_id)
    
    if lawsuit.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    return jsonify(lawsuit.to_dict())

@api.route('/processos/<int:lawsuit_id>', methods=['PUT'])
@login_required
def update_lawsuit(lawsuit_id):
    """Atualiza um processo"""
    lawsuit = Lawsuit.query.get_or_404(lawsuit_id)
    
    if lawsuit.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    data = request.get_json()
    
    # Atualizar campos
    for field in ['number', 'title', 'court', 'court_section', 'nature', 
                  'subject', 'status', 'phase', 'priority', 'value']:
        if field in data:
            setattr(lawsuit, field, data[field])
    
    # Atualizar datas
    if data.get('deadline_date'):
        lawsuit.deadline_date = datetime.strptime(data['deadline_date'], '%Y-%m-%d')
    if data.get('hearing_date'):
        lawsuit.hearing_date = datetime.strptime(data['hearing_date'], '%Y-%m-%d')
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'lawsuit': lawsuit.to_dict()
    })

@api.route('/processos/<int:lawsuit_id>', methods=['DELETE'])
@login_required
def delete_lawsuit(lawsuit_id):
    """Exclui um processo"""
    lawsuit = Lawsuit.query.get_or_404(lawsuit_id)
    
    if lawsuit.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    db.session.delete(lawsuit)
    db.session.commit()
    
    return jsonify({'success': True})

# ===== ROTAS DE TAREFAS =====

@api.route('/tarefas', methods=['GET'])
@login_required
def get_tasks():
    """Lista todas as tarefas do usuário"""
    status = request.args.get('status')
    lawsuit_id = request.args.get('lawsuit_id')
    
    query = Task.query.filter_by(user_id=current_user.id)
    
    if status:
        query = query.filter_by(status=status)
    if lawsuit_id:
        query = query.filter_by(lawsuit_id=lawsuit_id)
    
    tasks = query.order_by(Task.created_at.desc()).all()
    
    return jsonify({
        'tasks': [task.to_dict() for task in tasks]
    })

@api.route('/tarefas', methods=['POST'])
@login_required
def create_task():
    """Cria uma nova tarefa"""
    data = request.get_json()
    
    if not data.get('title'):
        return jsonify({'error': 'Título é obrigatório'}), 400
    
    task = Task(
        title=data['title'],
        description=data.get('description'),
        status=data.get('status', 'pendente'),
        priority=data.get('priority', 'normal'),
        user_id=current_user.id,
        lawsuit_id=data.get('lawsuit_id')
    )
    
    if data.get('due_date'):
        task.due_date = datetime.strptime(data['due_date'], '%Y-%m-%d')
    
    db.session.add(task)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'task': task.to_dict()
    }), 201

@api.route('/tarefas/<int:task_id>/status', methods=['PUT'])
@login_required
def update_task_status(task_id):
    """Atualiza o status de uma tarefa"""
    task = Task.query.get_or_404(task_id)
    
    if task.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    data = request.get_json()
    new_status = data.get('status')
    
    if new_status not in ['pendente', 'em_andamento', 'concluida', 'cancelada']:
        return jsonify({'error': 'Status inválido'}), 400
    
    task.status = new_status
    
    if new_status == 'concluida':
        task.completed_at = datetime.now()
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'task': task.to_dict()
    })

@api.route('/tarefas/<int:task_id>', methods=['DELETE'])
@login_required
def delete_task(task_id):
    """Exclui uma tarefa"""
    task = Task.query.get_or_404(task_id)
    
    if task.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    db.session.delete(task)
    db.session.commit()
    
    return jsonify({'success': True})

# ===== ROTAS DE IA =====

@api.route('/ai/personas', methods=['GET'])
@login_required
def get_personas():
    """Lista todas as personas do usuário"""
    personas = Persona.query.filter_by(user_id=current_user.id).all()
    
    return jsonify({
        'personas': [persona.to_dict() for persona in personas]
    })

@api.route('/ai/personas', methods=['POST'])
@login_required
def create_persona():
    """Cria uma nova persona"""
    data = request.get_json()
    
    if not data.get('name'):
        return jsonify({'error': 'Nome é obrigatório'}), 400
    
    persona = Persona(
        name=data['name'],
        description=data.get('description'),
        status='draft',
        user_id=current_user.id
    )
    
    db.session.add(persona)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'persona': persona.to_dict()
    }), 201

@api.route('/ai/train-persona', methods=['POST'])
@login_required
def train_persona():
    """Treina uma persona com documentos"""
    # Esta é uma implementação simplificada
    # Em produção, processaria os documentos de forma assíncrona
    
    data = request.get_json()
    persona_id = data.get('persona_id')
    
    if not persona_id:
        return jsonify({'error': 'ID da persona é obrigatório'}), 400
    
    persona = Persona.query.get_or_404(persona_id)
    
    if persona.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    # Simular treinamento
    persona.status = 'trained'
    persona.training_date = datetime.now()
    persona.style_features = {
        "formality_level": "formal",
        "sentence_structure": "complexa",
        "argumentation_style": "dedutivo"
    }
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Treinamento concluído com sucesso'
    })

@api.route('/ai/gems', methods=['GET'])
@login_required
def get_gems():
    """Lista todos os Gems do usuário"""
    gems = Gem.query.filter_by(user_id=current_user.id).all()
    
    return jsonify({
        'gems': [gem.to_dict() for gem in gems]
    })

@api.route('/ai/generate-document', methods=['POST'])
@login_required
def generate_document():
    """Gera um documento usando IA"""
    data = request.get_json()
    
    gem_id = data.get('gem_id')
    title = data.get('title')
    context = data.get('context')
    variables = data.get('variables', {})
    
    if not all([gem_id, title]):
        return jsonify({'error': 'Gem ID e título são obrigatórios'}), 400
    
    # Buscar gem
    gem = Gem.query.get_or_404(gem_id)
    
    if gem.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    # Buscar persona se disponível
    persona = None
    if gem.persona_id:
        persona = Persona.query.get(gem.persona_id)
    
    # Gerar documento (simplificado)
    try:
        # Substituir variáveis no template
        content = gem.template
        for key, value in variables.items():
            content = content.replace(f'[{key}]', str(value))
        
        # Adicionar conteúdo gerado
        content += f"\n\n{context}"
        
        # Incrementar contador de uso
        gem.usage_count += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'document': content,
            'title': title
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ===== ROTAS DE SCRAPING =====

@api.route('/scraping/search/<process_number>', methods=['GET'])
@login_required
def search_process(process_number):
    """Busca informações de um processo"""
    try:
        result = court_manager.search_process(process_number)
        
        if result.success:
            return jsonify({
                'success': True,
                'process_info': {
                    'number': result.process_info.number,
                    'court': result.process_info.court,
                    'subject': result.process_info.subject,
                    'phase': result.process_info.phase
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': result.error_message
            }), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/scraping/progress/<process_number>', methods=['GET'])
@login_required
def get_progress(process_number):
    """Obtém andamentos de um processo"""
    court = request.args.get('court', court_manager.identify_court(process_number))
    
    try:
        progresses = court_manager.get_progress(process_number, court)
        
        return jsonify({
            'success': True,
            'progresses': [
                {
                    'date': p.date.isoformat(),
                    'description': p.description,
                    'type': p.type,
                    'importance': p.importance
                }
                for p in progresses
            ]
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ===== UTILIDADES =====

@api.route('/dashboard/stats', methods=['GET'])
@login_required
def get_dashboard_stats():
    """Obtém estatísticas do dashboard"""
    stats = {
        'total_processos': Lawsuit.query.filter_by(user_id=current_user.id).count(),
        'processos_ativos': Lawsuit.query.filter_by(user_id=current_user.id, status='ativo').count(),
        'tarefas_pendentes': Task.query.filter_by(user_id=current_user.id, status='pendente').count(),
        'clientes_ativos': Client.query.filter_by(user_id=current_user.id).count(),
        'prazos_proximos': Lawsuit.query.filter(
            Lawsuit.user_id == current_user.id,
            Lawsuit.deadline_date <= datetime.now() + timedelta(days=7),
            Lawsuit.status == 'ativo'
        ).count()
    }
    
    return jsonify({
        'success': True,
        'stats': stats
    })

# Registrar blueprint
app.register_blueprint(api)