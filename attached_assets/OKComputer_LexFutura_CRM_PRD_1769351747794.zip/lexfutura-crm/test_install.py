#!/usr/bin/env python
"""
Script de teste para verificar a instalação do LexFutura CRM
"""

import sys
import os

def test_imports():
    """Testa se todos os módulos podem ser importados"""
    print("Testando importações...")
    
    try:
        import flask
        print("✓ Flask importado com sucesso")
    except ImportError as e:
        print(f"✗ Erro ao importar Flask: {e}")
        return False
    
    try:
        import flask_sqlalchemy
        print("✓ Flask-SQLAlchemy importado com sucesso")
    except ImportError as e:
        print(f"✗ Erro ao importar Flask-SQLAlchemy: {e}")
        return False
    
    try:
        import flask_login
        print("✓ Flask-Login importado com sucesso")
    except ImportError as e:
        print(f"✗ Erro ao importar Flask-Login: {e}")
        return False
    
    try:
        import flask_socketio
        print("✓ Flask-SocketIO importado com sucesso")
    except ImportError as e:
        print(f"✗ Erro ao importar Flask-SocketIO: {e}")
        return False
    
    try:
        import openai
        print("✓ OpenAI importado com sucesso")
    except ImportError as e:
        print(f"⚠ OpenAI não disponível (opcional): {e}")
    
    try:
        import selenium
        print("✓ Selenium importado com sucesso")
    except ImportError as e:
        print(f"⚠ Selenium não disponível (opcional): {e}")
    
    try:
        import bs4
        print("✓ BeautifulSoup importado com sucesso")
    except ImportError as e:
        print(f"⚠ BeautifulSoup não disponível (opcional): {e}")
    
    return True

def test_app_structure():
    """Testa a estrutura da aplicação"""
    print("\nTestando estrutura da aplicação...")
    
    required_files = [
        'app.py',
        'config.py',
        'run.py',
        'requirements.txt',
        '.env',
        'models/__init__.py',
        'static/css/style.css',
        'static/js/main.js',
        'templates/base.html',
        'templates/dashboard.html',
        'templates/login.html'
    ]
    
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"✓ {file_path} existe")
        else:
            print(f"✗ {file_path} não encontrado")
            return False
    
    return True

def test_database():
    """Testa a conexão com o banco de dados"""
    print("\nTestando banco de dados...")
    
    try:
        # Adicionar o diretório atual ao path
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        from app import app, db
        from models import User, Client, Lawsuit, Task
        
        with app.app_context():
            # Testar conexão
            db.engine.connect()
            print("✓ Conexão com banco de dados estabelecida")
            
            # Testar criação de tabelas
            db.create_all()
            print("✓ Tabelas criadas com sucesso")
            
            # Testar inserção
            user_count = User.query.count()
            print(f"✓ Query funcionando (usuários: {user_count})")
            
        return True
        
    except Exception as e:
        print(f"✗ Erro no banco de dados: {e}")
        return False

def test_config():
    """Testa as configurações"""
    print("\nTestando configurações...")
    
    try:
        from config import Config
        
        config = Config()
        
        if config.SECRET_KEY:
            print("✓ SECRET_KEY configurada")
        else:
            print("✗ SECRET_KEY não configurada")
            return False
        
        if config.SQLALCHEMY_DATABASE_URI:
            print(f"✓ DATABASE_URI: {config.SQLALCHEMY_DATABASE_URI}")
        else:
            print("✗ DATABASE_URI não configurada")
            return False
        
        return True
        
    except Exception as e:
        print(f"✗ Erro nas configurações: {e}")
        return False

def test_models():
    """Testa os modelos de dados"""
    print("\nTestando modelos de dados...")
    
    try:
        from models import User, Client, Lawsuit, Task, Progress, Persona, Gem
        
        # Testar criação de instâncias
        user = User(name="Test", email="test@example.com")
        print("✓ Modelo User criado")
        
        client = Client(name="Cliente Teste", user_id=1)
        print("✓ Modelo Client criado")
        
        lawsuit = Lawsuit(number="123", title="Teste", user_id=1, client_id=1)
        print("✓ Modelo Lawsuit criado")
        
        task = Task(title="Tarefa Teste", user_id=1)
        print("✓ Modelo Task criado")
        
        progress = Progress(date=datetime.now(), description="Teste", lawsuit_id=1)
        print("✓ Modelo Progress criado")
        
        persona = Persona(name="Persona Teste", user_id=1)
        print("✓ Modelo Persona criado")
        
        gem = Gem(name="Gem Teste", document_type="teste", user_id=1)
        print("✓ Modelo Gem criado")
        
        return True
        
    except Exception as e:
        print(f"✗ Erro nos modelos: {e}")
        return False

def main():
    """Função principal de teste"""
    print("=" * 60)
    print("LexFutura CRM - Teste de Instalação")
    print("=" * 60)
    
    tests = [
        ("Importações", test_imports),
        ("Estrutura", test_app_structure),
        ("Configurações", test_config),
        ("Banco de Dados", test_database),
        ("Modelos", test_models)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n{'=' * 20} {test_name} {'=' * 20}")
        if test_func():
            passed += 1
            print(f"✓ {test_name} - PASSOU")
        else:
            print(f"✗ {test_name} - FALHOU")
    
    print("\n" + "=" * 60)
    print(f"RESULTADO: {passed}/{total} testes passaram")
    
    if passed == total:
        print("🎉 Tudo pronto! Execute 'python run.py' para iniciar o sistema.")
        print("🌐 Acesse: http://localhost:5000")
        print("👤 Login: admin@lexfutura.com / admin123")
    else:
        print("❌ Alguns testes falharam. Verifique os erros acima.")
        print("💡 Dica: Instale as dependências com 'pip install -r requirements.txt'")
    
    print("=" * 60)

if __name__ == '__main__':
    main()