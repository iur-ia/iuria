from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Task(db.Model):
    __tablename__ = 'tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default='pendente')  # pendente, em_andamento, concluida, cancelada
    priority = db.Column(db.String(20), default='normal')  # baixa, normal, alta, urgente
    
    # Datas
    due_date = db.Column(db.Date)  # Data de vencimento
    completed_at = db.Column(db.DateTime)  # Data de conclusão
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Chaves estrangeiras
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    lawsuit_id = db.Column(db.Integer, db.ForeignKey('lawsuits.id'), nullable=True)
    
    def __repr__(self):
        return f'<Task {self.title}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'priority': self.priority,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'lawsuit_title': self.lawsuit.title if self.lawsuit else None,
            'created_at': self.created_at.isoformat()
        }