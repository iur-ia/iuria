from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Lawsuit(db.Model):
    __tablename__ = 'lawsuits'
    
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(50), nullable=False)  # Número do processo
    title = db.Column(db.String(200), nullable=False)  # Título/apelido do processo
    court = db.Column(db.String(100))  # Tribunal
    court_section = db.Column(db.String(100))  # Vara/Seção
    nature = db.Column(db.String(100))  # Natureza jurídica
    subject = db.Column(db.String(200))  # Assunto
    status = db.Column(db.String(20), default='ativo')  # ativo, suspenso, arquivado, finalizado
    phase = db.Column(db.String(50))  # Fase processual
    value = db.Column(db.Float)  # Valor da causa
    priority = db.Column(db.String(20), default='normal')  # baixa, normal, alta, urgente
    
    # Datas importantes
    deadline_date = db.Column(db.Date)  # Data de prazo
    hearing_date = db.Column(db.Date)  # Data de audiência
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Chaves estrangeiras
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)
    
    # Relacionamentos
    progresses = db.relationship('Progress', backref='lawsuit', lazy=True, cascade='all, delete-orphan')
    tasks = db.relationship('Task', backref='lawsuit', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Lawsuit {self.number}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'number': self.number,
            'title': self.title,
            'court': self.court,
            'status': self.status,
            'phase': self.phase,
            'priority': self.priority,
            'deadline_date': self.deadline_date.isoformat() if self.deadline_date else None,
            'hearing_date': self.hearing_date.isoformat() if self.hearing_date else None,
            'client_name': self.client.name if self.client else None,
            'progresses_count': len(self.progresses),
            'tasks_count': len(self.tasks)
        }