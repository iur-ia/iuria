from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Progress(db.Model):
    __tablename__ = 'progresses'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, nullable=False)  # Data da movimentação
    description = db.Column(db.Text, nullable=False)  # Descrição do andamento
    type = db.Column(db.String(50))  # Tipo de andamento
    importance = db.Column(db.String(20), default='normal')  # baixa, normal, alta, critica
    source = db.Column(db.String(50), default='manual')  # manual, scraping, api
    
    # Dados brutos do tribunal (se aplicável)
    raw_data = db.Column(db.JSON)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Chaves estrangeiras
    lawsuit_id = db.Column(db.Integer, db.ForeignKey('lawsuits.id'), nullable=False)
    
    def __repr__(self):
        return f'<Progress {self.id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat(),
            'description': self.description,
            'type': self.type,
            'importance': self.importance,
            'source': self.source,
            'lawsuit_number': self.lawsuit.number if self.lawsuit else None,
            'created_at': self.created_at.isoformat()
        }