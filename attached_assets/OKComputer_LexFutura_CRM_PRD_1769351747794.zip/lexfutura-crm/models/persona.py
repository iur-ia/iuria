from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Persona(db.Model):
    __tablename__ = 'personas'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # Nome da persona
    description = db.Column(db.Text)  # Descrição da persona
    
    # Características de estilo extraídas
    style_features = db.Column(db.JSON)  # Features de estilo em formato JSON
    sample_documents = db.Column(db.JSON)  # Referências aos documentos de amostra
    
    # Status
    status = db.Column(db.String(20), default='draft')  # draft, trained, active
    training_date = db.Column(db.DateTime)  # Data do treinamento
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Chaves estrangeiras
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relacionamentos
    gems = db.relationship('Gem', backref='persona', lazy=True)
    
    def __repr__(self):
        return f'<Persona {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'status': self.status,
            'training_date': self.training_date.isoformat() if self.training_date else None,
            'gems_count': len(self.gems),
            'created_at': self.created_at.isoformat()
        }