from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Gem(db.Model):
    __tablename__ = 'gems'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # Nome do Gem
    description = db.Column(db.Text)  # Descrição do Gem
    document_type = db.Column(db.String(50), nullable=False)  # Tipo de documento
    
    # Template e instruções
    template = db.Column(db.Text)  # Template base do documento
    instructions = db.Column(db.Text)  # Instruções para a IA
    
    # Campos variáveis
    variables = db.Column(db.JSON)  # Campos variáveis esperados
    
    # Status
    status = db.Column(db.String(20), default='draft')  # draft, active, deprecated
    usage_count = db.Column(db.Integer, default=0)  # Contador de uso
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Chaves estrangeiras
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    persona_id = db.Column(db.Integer, db.ForeignKey('personas.id'), nullable=True)
    
    def __repr__(self):
        return f'<Gem {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'document_type': self.document_type,
            'status': self.status,
            'usage_count': self.usage_count,
            'persona_name': self.persona.name if self.persona else None,
            'created_at': self.created_at.isoformat()
        }