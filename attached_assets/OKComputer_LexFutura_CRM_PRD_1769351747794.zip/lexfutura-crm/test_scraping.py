#!/usr/bin/env python
"""
Script de teste para scraping - LexFutura CRM

Este script testa o scraping de tribunais com Playwright e Selenium.
"""

import sys
import os
from datetime import datetime

# Adicionar diretório ao path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_playwright_installation():
    """Testa se Playwright está instalado corretamente"""
    print("=" * 60)
    print("Teste de Instalação do Playwright")
    print("=" * 60)
    
    try:
        from playwright.sync_api import sync_playwright
        print("✓ Playwright importado com sucesso")
        
        # Testar navegador
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            print("✓ Navegador Chromium iniciado")
            browser.close()
        
        return True
        
    except ImportError as e:
        print(f"✗ Playwright não instalado: {e}")
        print("\nExecute: python setup_playwright.py")
        return False
    except Exception as e:
        print(f"✗ Erro ao testar Playwright: {e}")
        return False

def test_scraping_simulation():
    """Testa scraping em modo simulação (sem acessar tribunais reais)"""
    print("\n" + "=" * 60)
    print("Teste de Scraping - Modo Simulação")
    print("=" * 60)
    
    try:
        from scraping.courts import CourtScraperManager, ScrapingResult, ProgressInfo
        
        # Criar gerenciador
        manager = CourtScraperManager()
        
        # Testar identificação de tribunal
        print("\n1. Testando identificação de tribunal...")
        courts = [
            "1234567-89.2023.8.26.0100",  # TJSP
            "1234567-89.2023.5.01.0001",  # TRF
            "1234567-89.2023.4.01.0000",  # STF
        ]
        
        for court_number in courts:
            court = manager.identify_court(court_number)
            print(f"  {court_number} → {court}")
        
        # Testar scraping simulado
        print("\n2. Testando scraping simulado...")
        result = manager.search_process("1234567-89.2023.8.26.0100")
        
        if result.success:
            print(f"✓ Processo encontrado: {result.process_info.number}")
            print(f"  Tribunal: {result.process_info.court}")
            print(f"  Assunto: {result.process_info.subject}")
            print(f"  Fase: {result.process_info.phase}")
        else:
            print(f"✗ Erro: {result.error_message}")
        
        # Testar andamentos
        print("\n3. Testando andamentos...")
        progresses = manager.get_progress("1234567-89.2023.8.26.0100", "TJSP")
        
        if progresses:
            print(f"✓ Encontrados {len(progresses)} andamentos")
            for progress in progresses[:3]:  # Mostrar apenas 3 primeiros
                print(f"  {progress.date.strftime('%d/%m/%Y')} - {progress.description[:50]}...")
        else:
            print("⚠ Nenhum andamento encontrado (modo simulação)")
        
        return True
        
    except Exception as e:
        print(f"✗ Erro no teste de scraping: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_scraping_real():
    """Testa scraping com tribunais reais (requer Playwright configurado)"""
    print("\n" + "=" * 60)
    print("Teste de Scraping - Tribunais Reais")
    print("=" * 60)
    
    # Verificar se quer executar teste real
    print("\n⚠️  AVISO: Este teste acessará tribunais reais.")
    print("   Isso pode levar alguns minutos e requer internet.")
    
    response = input("\nDeseja continuar? (s/N): ")
    if response.lower() != 's':
        print("Teste cancelado.")
        return False
    
    try:
        from playwright.sync_api import sync_playwright
        from scraping.courts import TJSPScraper, TRFScraper
        
        print("\n1. Testando TJSP...")
        
        # Testar TJSP
        tjsp = TJSPScraper()
        result = tjsp.search_process("0000000-00.0000.0.00.0000")  # Número inválido para teste
        
        if result.success:
            print("✓ TJSP acessível (mas número inválido)")
        else:
            print(f"⚠ TJSP: {result.error_message[:100]}...")
        
        tjsp._close_browser()  # Fechar browser
        
        print("\n2. Testando TRF...")
        
        # Testar TRF
        trf = TRFScraper()
        result = trf.search_process("0000000-00.0000.0.00.0000")
        
        if result.success:
            print("✓ TRF acessível")
        else:
            print(f"⚠ TRF: {result.error_message[:100]}...")
        
        return True
        
    except Exception as e:
        print(f"✗ Erro no teste real: {e}")
        return False

def test_browser_comparison():
    """Compara performance entre Playwright e Selenium"""
    print("\n" + "=" * 60)
    print("Comparação de Performance")
    print("=" * 60)
    
    print("""
Playwright vs Selenium:

✅ PLAYWRIGHT:
  + Mais rápido (2-3x mais rápido)
  + Mais confiável
  + Melhor suporte a navegadores modernos
  + APIs mais intuitivas
  + Melhor isolamento de contextos
  + Suporte nativo para mobile

⚠️  SELENIUM (Fallback):
  + Mais maduro e estabilizado
  + Maior comunidade
  + Mais documentação
  + Suporte a mais navegadores antigos
  - Mais lento
  - APIs mais verbosas
  - Problemas com estabilidade

RECOMENDAÇÃO: Use Playwright como padrão, Selenium como fallback.
""")

def show_next_steps():
    """Mostra próximos passos"""
    print("\n" + "=" * 60)
    print("Próximos Passos")
    print("=" * 60)
    
    print("""
1. EXECUTAR O SISTEMA:
   python run.py
   
2. TESTAR SCRAPING:
   - Acesse: http://localhost:5000
   - Vá para: AI Studio > Monitoramento
   - Adicione um processo e teste o scraping

3. CONFIGURAR PARA PRODUÇÃO:
   - Configure variáveis de ambiente (.env)
   - Use PostgreSQL ao invés de SQLite
   - Configure Redis para caching
   - Configure cron jobs para scraping automático

4. PERSONALIZAR:
   - Adicione mais tribunais em scraping/courts.py
   - Personalize cores em static/css/style.css
   - Adicione mais templates (Gems) em AI Studio

5. MONITORAR:
   - Verifique logs em logs/
   - Configure alertas de erro
   - Monitore performance do scraping

6. ATUALIZAR:
   - Execute: playwright install chromium --with-deps
   - Mantenha navegadores atualizados
   - Teste após atualizações do sistema
""")

if __name__ == '__main__':
    print("Teste de Scraping - LexFutura CRM")
    print("=" * 60)
    
    # 1. Testar Playwright
    playwright_ok = test_playwright_installation()
    
    # 2. Testar scraping simulado
    scraping_ok = test_scraping_simulation()
    
    # 3. Comparar browsers
    test_browser_comparison()
    
    # 4. Perguntar sobre teste real
    if playwright_ok:
        print("\n" + "=" * 60)
        print("Opção: Teste com tribunais reais")
        print("=" * 60)
        print("Recomendado apenas se Playwright estiver configurado.")
        
        response = input("\nDeseja testar com tribunais reais? (s/N): ")
        if response.lower() == 's':
            test_scraping_real()
    
    # 5. Mostrar próximos passos
    show_next_steps()
    
    # Resumo
    print("\n" + "=" * 60)
    print("RESUMO DOS TESTES")
    print("=" * 60)
    
    if playwright_ok and scraping_ok:
        print("✅ Sistema pronto para uso!")
        print("   Playwright configurado e scraping funcionando.")
    elif scraping_ok:
        print("✅ Sistema funcional com Selenium como fallback.")
        print("   Considere configurar Playwright para melhor performance.")
    else:
        print("❌ Problemas detectados.")
        print("   Execute: python setup_playwright.py")
        print("   Ou verifique a documentação.")
    
    print("=" * 60)