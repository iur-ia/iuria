from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_migrate import Migrate
from flask_socketio import SocketIO, emit
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

# Inicializar Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///lexfutura.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar extensões
db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
socketio = SocketIO(app, cors_allowed_origins="*")

# Importar modelos
from models import User, Client, Lawsuit, Task, Progress, Persona, Gem

# Carregar usuário para login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Rotas principais
@app.route('/')
@login_required
def index():
    # Dashboard principal
    stats = {
        'total_processos': Lawsuit.query.filter_by(user_id=current_user.id).count(),
        'processos_ativos': Lawsuit.query.filter_by(user_id=current_user.id, status='ativo').count(),
        'tarefas_pendentes': Task.query.filter_by(user_id=current_user.id, status='pendente').count(),
        'clientes_ativos': Client.query.filter_by(user_id=current_user.id).count()
    }
    
    # Processos com prazos próximos
    upcoming_deadlines = Lawsuit.query.filter(
        Lawsuit.user_id == current_user.id,
        Lawsuit.deadline_date <= datetime.now() + timedelta(days=7),
        Lawsuit.status == 'ativo'
    ).order_by(Lawsuit.deadline_date.asc()).limit(5).all()
    
    # Tarefas recentes
    recent_tasks = Task.query.filter_by(user_id=current_user.id).order_by(Task.created_at.desc()).limit(10).all()
    
    return render_template('dashboard.html', 
                         stats=stats, 
                         upcoming_deadlines=upcoming_deadlines,
                         recent_tasks=recent_tasks)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Email ou senha inválidos.', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logout realizado com sucesso.', 'info')
    return redirect(url_for('login'))

@app.route('/processos')
@login_required
def lawsuits():
    page = request.args.get('page', 1, type=int)
    lawsuits = Lawsuit.query.filter_by(user_id=current_user.id).paginate(
        page=page, per_page=20, error_out=False
    )
    return render_template('lawsuits/list.html', lawsuits=lawsuits)

@app.route('/processos/novo', methods=['GET', 'POST'])
@login_required
def new_lawsuit():
    if request.method == 'POST':
        lawsuit = Lawsuit(
            number=request.form['number'],
            title=request.form['title'],
            court=request.form['court'],
            nature=request.form['nature'],
            status=request.form.get('status', 'ativo'),
            client_id=request.form['client_id'],
            user_id=current_user.id
        )
        
        if request.form.get('deadline_date'):
            lawsuit.deadline_date = datetime.strptime(request.form['deadline_date'], '%Y-%m-%d')
        
        db.session.add(lawsuit)
        db.session.commit()
        flash('Processo cadastrado com sucesso!', 'success')
        return redirect(url_for('lawsuits'))
    
    clients = Client.query.filter_by(user_id=current_user.id).all()
    return render_template('lawsuits/new.html', clients=clients)

@app.route('/clientes')
@login_required
def clients():
    page = request.args.get('page', 1, type=int)
    clients = Client.query.filter_by(user_id=current_user.id).paginate(
        page=page, per_page=20, error_out=False
    )
    return render_template('clients/list.html', clients=clients)

@app.route('/clientes/novo', methods=['GET', 'POST'])
@login_required
def new_client():
    if request.method == 'POST':
        client = Client(
            name=request.form['name'],
            email=request.form.get('email'),
            phone=request.form.get('phone'),
            document=request.form.get('document'),
            address=request.form.get('address'),
            user_id=current_user.id
        )
        db.session.add(client)
        db.session.commit()
        flash('Cliente cadastrado com sucesso!', 'success')
        return redirect(url_for('clients'))
    
    return render_template('clients/new.html')

@app.route('/tarefas')
@login_required
def tasks():
    tasks = Task.query.filter_by(user_id=current_user.id).order_by(Task.created_at.desc()).all()
    return render_template('tasks/kanban.html', tasks=tasks)

@app.route('/tarefas/nova', methods=['POST'])
@login_required
def new_task():
    task = Task(
        title=request.form['title'],
        description=request.form.get('description'),
        status='pendente',
        user_id=current_user.id,
        lawsuit_id=request.form.get('lawsuit_id')
    )
    db.session.add(task)
    db.session.commit()
    flash('Tarefa criada com sucesso!', 'success')
    return redirect(url_for('tasks'))

@app.route('/ai-studio')
@login_required
def ai_studio():
    personas = Persona.query.filter_by(user_id=current_user.id).all()
    gems = Gem.query.filter_by(user_id=current_user.id).all()
    return render_template('ai/studio.html', personas=personas, gems=gems)

# API endpoints para funcionalidades AJAX
@app.route('/api/tasks/<int:task_id>/status', methods=['PUT'])
@login_required
def update_task_status(task_id):
    task = Task.query.get_or_404(task_id)
    if task.user_id != current_user.id:
        return jsonify({'error': 'Acesso negado'}), 403
    
    task.status = request.json['status']
    db.session.commit()
    return jsonify({'success': True})

# Importar e registrar rotas da API
from api_routes import api
app.register_blueprint(api)

# WebSocket para notificações em tempo real
@socketio.on('connect')
def handle_connect():
    if current_user.is_authenticated:
        emit('message', {'data': f'Conectado como {current_user.name}'})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Criar usuário admin se não existir
        if not User.query.filter_by(email='admin@lexfutura.com').first():
            admin = User(
                name='Administrador',
                email='admin@lexfutura.com',
                password_hash=generate_password_hash('admin123')
            )
            db.session.add(admin)
            db.session.commit()
    
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)