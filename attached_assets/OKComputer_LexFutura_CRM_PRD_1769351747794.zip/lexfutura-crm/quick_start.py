#!/usr/bin/env python
"""
Quick Start - LexFutura CRM

Este script faz TUDO automaticamente:
1. Verifica dependências
2. Instala Playwright
3. Configura banco de dados
4. Cria dados de exemplo
5. Inicia o servidor
"""

import subprocess
import sys
import os
import time

def run_command(cmd, description=""):
    """Executa comando e mostra progresso"""
    print(f"\n{'='*60}")
    print(f"EXECUTANDO: {description}")
    print(f"COMANDO: {cmd}")
    print('='*60)
    
    try:
        result = subprocess.run(cmd, shell=True, capture_output=False, text=True)
        if result.returncode == 0:
            print(f"✅ SUCESSO: {description}")
            return True
        else:
            print(f"❌ ERRO: {description}")
            return False
    except Exception as e:
        print(f"❌ ERRO: {description} - {e}")
        return False

def check_python():
    """Verifica versão do Python"""
    print("="*60)
    print("VERIFICANDO PYTHON")
    print("="*60)
    
    version = sys.version_info
    print(f"Python: {version.major}.{version.minor}.{version.micro}")
    
    if version.major == 3 and version.minor >= 8:
        print("✅ Python 3.8+ OK")
        return True
    else:
        print("❌ Python 3.8+ necessário")
        return False

def install_dependencies():
    """Instala todas as dependências"""
    print("="*60)
    print("INSTALANDO DEPENDÊNCIAS")
    print("="*60)
    
    commands = [
        ("pip install --upgrade pip", "Atualizando pip"),
        ("pip install -r requirements.txt", "Instalando dependências do projeto"),
    ]
    
    for cmd, desc in commands:
        if not run_command(cmd, desc):
            return False
    
    return True

def setup_playwright():
    """Configura Playwright"""
    print("="*60)
    print("CONFIGURANDO PLAYWRIGHT")
    print("="*60)
    
    commands = [
        ("playwright install chromium", "Instalando navegador Chromium"),
        ("playwright install firefox", "Instalando navegador Firefox (opcional)"),
    ]
    
    for cmd, desc in commands:
        if not run_command(cmd, desc):
            print(f"⚠️  {desc} - Continuando mesmo assim...")
    
    return True

def setup_database():
    """Configura banco de dados"""
    print("="*60)
    print("CONFIGURANDO BANCO DE DADOS")
    print("="*60)
    
    # Criar diretórios necessários
    dirs = ['uploads', 'logs', 'temp']
    for dir_name in dirs:
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)
            print(f"✅ Diretório criado: {dir_name}")
    
    # Criar banco de dados e dados de exemplo
    commands = [
        ("python -c 'from app import app, db; db.create_all(); print(\"Banco criado\")'", "Criando banco de dados"),
        ("python migrations.py init", "Criando dados de exemplo"),
    ]
    
    for cmd, desc in commands:
        if not run_command(cmd, desc):
            return False
    
    return True

def test_installation():
    """Testa instalação"""
    print("="*60)
    print("TESTANDO INSTALAÇÃO")
    print("="*60)
    
    commands = [
        ("python -c 'import flask; print(\"Flask OK\")'", "Testando Flask"),
        ("python -c 'import playwright; print(\"Playwright OK\")'", "Testando Playwright"),
        ("python -c 'from app import app; print(\"App OK\")'", "Testando aplicação"),
    ]
    
    for cmd, desc in commands:
        if not run_command(cmd, desc):
            print(f"⚠️  {desc} - Continuando...")
    
    return True

def start_server():
    """Inicia servidor"""
    print("="*60)
    print("INICIANDO SERVIDOR")
    print("="*60)
    
    print("""
🚀 LEXFUTURA CRM ESTÁ PRONTO!

✅ Dependências instaladas
✅ Playwright configurado  
✅ Banco de dados criado
✅ Dados de exemplo inseridos
✅ Testes realizados

🌐 Acesse: http://localhost:5000
👤 Login: admin@lexfutura.com
🔑 Senha: admin123

🛑 PRESSIONE CTRL+C PARA PARAR O SERVIDOR
""")
    
    time.sleep(3)
    
    try:
        subprocess.run("python run.py", shell=True)
    except KeyboardInterrupt:
        print("\n\n🛑 Servidor parado pelo usuário")
    except Exception as e:
        print(f"\n❌ Erro ao iniciar servidor: {e}")

def main():
    """Função principal"""
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║   ███████╗██╗  ██╗██████╗ ███████╗██╗     ██╗██████╗ ██████╗ ║
    ║   ██╔════╝╚██╗██╔╝██╔══██╗██╔════╝██║     ██║██╔══██╗██╔══██╗║
    ║   █████╗   ╚███╔╝ ██████╔╝█████╗  ██║     ██║██████╔╝██║  ██║║
    ║   ██╔══╝   ██╔██╗ ██╔═══╝ ██╔══╝  ██║     ██║██╔══██╗██║  ██║║
    ║   ███████╗██╔╝ ██╗██║     ███████╗███████╗██║██║  ██║██████╔╝║
    ║   ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚═════╝ ║
    ║                                                              ║
    ║          SISTEMA DE GESTÃO JURÍDICA DE PRÓXIMA GERAÇÃO        ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    print("\n🎯 Este script vai instalar e configurar TUDO automaticamente!\n")
    
    steps = [
        (check_python, "Verificando Python"),
        (install_dependencies, "Instalando dependências"),
        (setup_playwright, "Configurando Playwright"),
        (setup_database, "Configurando banco de dados"),
        (test_installation, "Testando instalação"),
        (start_server, "Iniciando servidor"),
    ]
    
    for step_func, step_name in steps:
        print(f"\n{'='*60}")
        print(f"PASSO: {step_name}")
        print('='*60)
        
        if not step_func():
            print(f"\n❌ ERRO em: {step_name}")
            print("\nTente resolver o problema e execute novamente.")
            print("Ou execute os passos manualmente conforme README.md")
            return False
    
    return True

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n🛑 Execução interrompida pelo usuário")
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        import traceback
        traceback.print_exc()