"""
Módulo de Scraping de Tribunais

Este módulo implementa scrapers para os principais tribunais brasileiros,
permitindo a busca automática de andamentos processuais.
"""

import requests
import json
import time
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from bs4 import BeautifulSoup
import logging

# Playwright para scraping moderno
try:
    from playwright.sync_api import sync_playwright, Playwright, Browser, Page
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    logging.warning("Playwright não instalado. Instale com: pip install playwright && playwright install")

# Selenium como fallback
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False
    logging.warning("Selenium não instalado.")

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ProcessInfo:
    """Informações de um processo"""
    number: str
    court: str
    parties: List[Dict[str, str]] = field(default_factory=list)
    lawyers: List[Dict[str, str]] = field(default_factory=list)
    subject: str = ""
    value: float = 0.0
    phase: str = ""
    judge: str = ""

@dataclass
class ProgressInfo:
    """Informação de um andamento processual"""
    date: datetime
    description: str
    type: str = ""
    importance: str = "normal"
    raw_data: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ScrapingResult:
    """Resultado do scraping"""
    success: bool
    process_info: Optional[ProcessInfo] = None
    progresses: List[ProgressInfo] = field(default_factory=list)
    error_message: str = ""
    scraping_date: datetime = field(default_factory=datetime.now)

class CourtScraper(ABC):
    """Classe base para scrapers de tribunais"""
    
    def __init__(self, name: str, base_url: str):
        self.name = name
        self.base_url = base_url
        self.session = requests.Session()
        self.last_request_time = datetime.min
        self.rate_limit_delay = 1.0  # segundos entre requisições
    
    def _rate_limit(self):
        """Aplica rate limiting entre requisições"""
        now = datetime.now()
        time_since_last = (now - self.last_request_time).total_seconds()
        
        if time_since_last < self.rate_limit_delay:
            time.sleep(self.rate_limit_delay - time_since_last)
        
        self.last_request_time = datetime.now()
    
    @abstractmethod
    def search_process(self, process_number: str) -> ScrapingResult:
        """Busca informações de um processo"""
        pass
    
    @abstractmethod
    def get_progress(self, process_number: str, last_update: Optional[datetime] = None) -> List[ProgressInfo]:
        """Obtém andamentos de um processo"""
        pass
    
    def _clean_text(self, text: str) -> str:
        """Limpa texto extraído"""
        if not text:
            return ""
        
        # Remove espaços extras e quebras de linha
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        return text

class TJSPScraper(CourtScraper):
    """Scraper para Tribunal de Justiça de São Paulo com Playwright"""
    
    def __init__(self):
        super().__init__("TJSP", "https://esaj.tjsp.jus.br")
        self.rate_limit_delay = 2.0
        self.browser = None
        self.playwright = None
    
    def _init_browser(self):
        """Inicializa o navegador Playwright"""
        if not PLAYWRIGHT_AVAILABLE:
            raise Exception("Playwright não está instalado. Execute: pip install playwright && playwright install chromium")
        
        if self.playwright is None:
            self.playwright = sync_playwright().start()
            self.browser = self.playwright.chromium.launch(
                headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage']
            )
    
    def _close_browser(self):
        """Fecha o navegador"""
        if self.browser:
            self.browser.close()
        if self.playwright:
            self.playwright.stop()
    
    def search_process(self, process_number: str) -> ScrapingResult:
        """Busca processo no TJSP usando Playwright"""
        try:
            self._rate_limit()
            self._init_browser()
            
            # Formatar número do processo
            formatted_number = self._format_process_number(process_number)
            
            # Criar nova página
            page = self.browser.new_page()
            
            try:
                # Acessar página de consulta
                consulta_url = f"{self.base_url}/cpopg/search.do"
                page.goto(consulta_url, wait_until='networkidle', timeout=30000)
                
                # Aguardar e preencher formulário
                page.wait_for_selector("#numeroDigitoAnoUnificado", timeout=10000)
                page.fill("#numeroDigitoAnoUnificado", formatted_number)
                page.fill("#foroNumeroUnificado", "0000")
                
                # Tirar screenshot para debug (opcional)
                # page.screenshot(path=f"tjsp_{process_number}_form.png")
                
                # Clicar em consultar
                page.click("input[type='submit'][value='Consultar']")
                
                # Aguardar resultado
                page.wait_for_load_state('networkidle', timeout=10000)
                
                # Verificar se há resultado
                if page.locator(".mensagemErro").count() > 0:
                    error_msg = page.locator(".mensagemErro").text_content()
                    return ScrapingResult(success=False, error_message=error_msg)
                
                # Extrair informações do processo
                result = ScrapingResult(success=True)
                result.process_info = ProcessInfo(
                    number=process_number,
                    court="TJSP",
                    subject=self._extract_subject(page),
                    phase=self._extract_phase(page)
                )
                
                # Extrair partes
                result.process_info.parties = self._extract_parties(page)
                
                return result
                
            finally:
                page.close()
                
        except Exception as e:
            logger.error(f"Erro ao buscar processo {process_number}: {str(e)}")
            return ScrapingResult(success=False, error_message=str(e))
        finally:
            # Opcional: manter browser aberto para reuso
            pass
    
    def get_progress(self, process_number: str, last_update: Optional[datetime] = None) -> List[ProgressInfo]:
        """Obtém andamentos do TJSP"""
        try:
            self._rate_limit()
            self._init_browser()
            
            page = self.browser.new_page()
            
            try:
                # Acessar página de movimentações
                # URL específica para movimentações (ajustar conforme necessário)
                mov_url = f"{self.base_url}/cpopg/show.do?processo.numero={process_number}&processo.foro=0"
                page.goto(mov_url, wait_until='networkidle', timeout=30000)
                
                # Extrair movimentações
                progresses = []
                
                # Localizar tabela de movimentações
                rows = page.locator("table#tabelaUltimasMovimentacoes tr[class!='header']").all()
                
                for row in rows:
                    try:
                        date_cell = row.locator("td:first-child").text_content().strip()
                        desc_cell = row.locator("td:nth-child(2)").text_content().strip()
                        
                        if date_cell and desc_cell:
                            # Converter data
                            try:
                                date = datetime.strptime(date_cell, '%d/%m/%Y')
                            except:
                                date = datetime.now()
                            
                            progress = ProgressInfo(
                                date=date,
                                description=desc_cell,
                                type=self._classify_progress_type(desc_cell),
                                importance=self._classify_importance(desc_cell)
                            )
                            
                            progresses.append(progress)
                    except:
                        continue
                
                # Filtrar por data se necessário
                if last_update:
                    progresses = [p for p in progresses if p.date > last_update]
                
                return progresses
                
            finally:
                page.close()
                
        except Exception as e:
            logger.error(f"Erro ao obter andamentos do TJSP: {str(e)}")
            return []
    
    def _extract_subject(self, page) -> str:
        """Extrai o assunto do processo"""
        try:
            # Localizar campo de assunto
            if page.locator("#assuntoProcesso").count() > 0:
                return page.locator("#assuntoProcesso").text_content().strip()
            elif page.locator(".assunto").count() > 0:
                return page.locator(".assunto").text_content().strip()
            return ""
        except:
            return ""
    
    def _extract_phase(self, page) -> str:
        """Extrai a fase do processo"""
        try:
            # Localizar campo de fase
            if page.locator("#faseProcesso").count() > 0:
                return page.locator("#faseProcesso").text_content().strip()
            elif page.locator(".fase").count() > 0:
                return page.locator(".fase").text_content().strip()
            return ""
        except:
            return ""
    
    def _extract_parties(self, page) -> List[Dict[str, str]]:
        """Extrai as partes do processo"""
        parties = []
        try:
            # Localizar seção de partes
            partes_section = page.locator(".partes")
            if partes_section.count() > 0:
                # Extrair autor e réu
                autor = partes_section.locator(".autor").text_content().strip()
                reu = partes_section.locator(".reu").text_content().strip()
                
                if autor:
                    parties.append({"type": "autor", "name": autor})
                if reu:
                    parties.append({"type": "réu", "name": reu})
        except:
            pass
        
        return parties
    
    def _classify_progress_type(self, description: str) -> str:
        """Classifica o tipo de andamento"""
        desc_lower = description.lower()
        
        if any(word in desc_lower for word in ["petição", "peticao"]):
            return "peticao"
        elif any(word in desc_lower for word in ["juntada", "juntado"]):
            return "juntada"
        elif any(word in desc_lower for word in ["intimação", "intimacao"]):
            return "intimacao"
        elif any(word in desc_lower for word in ["sentença", "sentenca"]):
            return "sentenca"
        elif any(word in desc_lower for word in ["despacho"]):
            return "despacho"
        else:
            return "outro"
    
    def _format_process_number(self, number: str) -> str:
        """Formata número do processo para TJSP"""
        clean = re.sub(r'[^\d]', '', number)
        
        if len(clean) == 20:
            return f"{clean[:7]}-{clean[7:9]}.{clean[9:13]}.{clean[13]}.{clean[14:16]}.{clean[16:]}"
        
        return number
    
    def get_progress(self, process_number: str, last_update: Optional[datetime] = None) -> List[ProgressInfo]:
        """Obtém andamentos do TJSP"""
        # Simulação de andamentos
        progresses = []
        
        # Em produção, aqui faria o scraping real
        simulated_progresses = [
            ProgressInfo(
                date=datetime.now() - timedelta(days=5),
                description="Juntada de documentos",
                type="juntada",
                importance="normal"
            ),
            ProgressInfo(
                date=datetime.now() - timedelta(days=3),
                description="Intimação para contestar",
                type="intimacao",
                importance="alta"
            )
        ]
        
        # Filtrar por data de última atualização
        if last_update:
            progresses = [p for p in simulated_progresses if p.date > last_update]
        else:
            progresses = simulated_progresses
        
        return progresses
    
    def _format_process_number(self, number: str) -> str:
        """Formata número do processo para TJSP"""
        # Remove caracteres não numéricos
        clean = re.sub(r'[^\d]', '', number)
        
        if len(clean) == 20:
            return f"{clean[:7]}-{clean[7:9]}.{clean[9:13]}.{clean[13]}.{clean[14:16]}.{clean[16:]}"
        
        return number

class TRFScraper(CourtScraper):
    """Scraper para Tribunais Regionais Federais"""
    
    def __init__(self):
        super().__init__("TRF", "https://pje.trf1.jus.br")
        self.rate_limit_delay = 1.5
    
    def search_process(self, process_number: str) -> ScrapingResult:
        """Busca processo no TRF"""
        try:
            self._rate_limit()
            
            # TRF usa sistema PJe - pode usar API REST
            api_url = f"{self.base_url}/pje-consulta-api/api/processos/dados"
            
            response = self.session.post(
                api_url,
                json={"numeroProcesso": process_number},
                headers={
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Processar resposta
                result = ScrapingResult(success=True)
                result.process_info = ProcessInfo(
                    number=process_number,
                    court="TRF",
                    subject=data.get('classeProcessual', ''),
                    phase=data.get('faseProcessual', '')
                )
                
                # Adicionar partes
                if 'partes' in data:
                    for parte in data['partes']:
                        result.process_info.parties.append({
                            'type': parte.get('tipo'),
                            'name': parte.get('nome')
                        })
                
                return result
            else:
                return ScrapingResult(
                    success=False,
                    error_message=f"HTTP {response.status_code}: {response.text}"
                )
                
        except Exception as e:
            logger.error(f"Erro ao buscar processo {process_number}: {str(e)}")
            return ScrapingResult(success=False, error_message=str(e))
    
    def get_progress(self, process_number: str, last_update: Optional[datetime] = None) -> List[ProgressInfo]:
        """Obtém andamentos do TRF"""
        try:
            self._rate_limit()
            
            api_url = f"{self.base_url}/pje-consulta-api/api/processos/movimentacoes"
            
            response = self.session.post(
                api_url,
                json={"numeroProcesso": process_number},
                headers={
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                progresses = []
                
                for movimento in data.get('movimentacoes', []):
                    progress = ProgressInfo(
                        date=datetime.fromisoformat(movimento['dataHora'].replace('Z', '+00:00')),
                        description=movimento.get('descricao', ''),
                        type=movimento.get('tipo', ''),
                        raw_data=movimento
                    )
                    
                    # Classificar importância
                    progress.importance = self._classify_importance(progress.description)
                    
                    progresses.append(progress)
                
                # Filtrar por data
                if last_update:
                    progresses = [p for p in progresses if p.date > last_update]
                
                return progresses
            
        except Exception as e:
            logger.error(f"Erro ao obter andamentos do TRF: {str(e)}")
        
        return []
    
    def _classify_importance(self, description: str) -> str:
        """Classifica a importância de um andamento"""
        description_lower = description.lower()
        
        # Palavras-chave para importância crítica
        critical_keywords = [
            'sentença', 'decisão interlocutória', 'acórdão', 'despacho',
            'intimação', 'citação', 'mandado', 'prazo'
        ]
        
        # Palavras-chave para importância alta
        high_keywords = [
            'juntada', 'petição', 'recurso', 'apelação', 'embargos'
        ]
        
        if any(keyword in description_lower for keyword in critical_keywords):
            return "critica"
        elif any(keyword in description_lower for keyword in high_keywords):
            return "alta"
        else:
            return "normal"

class STFScraper(CourtScraper):
    """Scraper para Supremo Tribunal Federal"""
    
    def __init__(self):
        super().__init__("STF", "https://processo.stf.jus.br")
        self.rate_limit_delay = 3.0  # STF é mais restritivo
    
    def search_process(self, process_number: str) -> ScrapingResult:
        """Busca processo no STF"""
        try:
            self._rate_limit()
            
            # STF requer autenticação via certificado digital
            # Para demonstração, retornamos resultado simulado
            
            result = ScrapingResult(success=True)
            result.process_info = ProcessInfo(
                number=process_number,
                court="STF",
                subject="Ação Direta de Inconstitucionalidade",
                phase="Instrução"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao buscar processo {process_number}: {str(e)}")
            return ScrapingResult(success=False, error_message=str(e))
    
    def get_progress(self, process_number: str, last_update: Optional[datetime] = None) -> List[ProgressInfo]:
        """Obtém andamentos do STF"""
        # Simulação - em produção implementaria scraping real
        return []

class CourtScraperManager:
    """Gerenciador de scrapers de tribunais"""
    
    def __init__(self):
        self.scrapers = {
            'TJSP': TJSPScraper(),
            'TRF': TRFScraper(),
            'STF': STFScraper()
        }
    
    def get_scraper(self, court_code: str) -> Optional[CourtScraper]:
        """Obtém scraper para um tribunal"""
        return self.scrapers.get(court_code)
    
    def identify_court(self, process_number: str) -> str:
        """Identifica o tribunal pelo número do processo"""
        # Remove caracteres não numéricos
        clean = re.sub(r'[^\d]', '', process_number)
        
        if len(clean) < 6:
            return "unknown"
        
        # Identificar por padrões
        segmento = clean[13] if len(clean) > 13 else '0'
        
        if segmento in ['8', '9']:
            return "STF"
        elif segmento in ['5', '6']:
            return "STJ"
        elif segmento in ['3', '4']:
            return "TRF"
        elif segmento in ['1', '2']:
            # Estadual - identificar pelo estado
            # Por simplicidade, assumimos TJSP
            return "TJSP"
        
        return "unknown"
    
    def search_process(self, process_number: str) -> ScrapingResult:
        """Busca processo no tribunal apropriado"""
        court = self.identify_court(process_number)
        scraper = self.get_scraper(court)
        
        if scraper:
            return scraper.search_process(process_number)
        else:
            return ScrapingResult(
                success=False,
                error_message=f"Scraper não disponível para tribunal: {court}"
            )
    
    def get_progress(self, process_number: str, court: str, 
                    last_update: Optional[datetime] = None) -> List[ProgressInfo]:
        """Obtém andamentos do processo"""
        scraper = self.get_scraper(court)
        
        if scraper:
            return scraper.get_progress(process_number, last_update)
        
        return []

# Exportar classes principais
__all__ = [
    'CourtScraper',
    'TJSPScraper',
    'TRFScraper',
    'STFScraper',
    'CourtScraperManager',
    'ProcessInfo',
    'ProgressInfo',
    'ScrapingResult'
]    def get_progress(self, process_number: str, last_update: Optional[datetime] = None) -> List[ProgressInfo]:
        """Obtém andamentos do TRF"""
        try:
            self._rate_limit()
            
            api_url = f"{self.base_url}/pje-consulta-api/api/processos/movimentacoes"
            
            response = self.session.post(
                api_url,
                json={"numeroProcesso": process_number},
                headers={
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                progresses = []
                
                for movimento in data.get('movimentacoes', []):
                    progress = ProgressInfo(
                        date=datetime.fromisoformat(movimento['dataHora'].replace('Z', '+00:00')),
                        description=movimento.get('descricao', ''),
                        type=movimento.get('tipo', ''),
                        raw_data=movimento
                    )
                    
                    progress.importance = self._classify_importance(progress.description)
                    progresses.append(progress)
                
                # Filtrar por data
                if last_update:
                    progresses = [p for p in progresses if p.date > last_update]
                
                return progresses
            
        except Exception as e:
            logger.error(f"Erro ao obter andamentos do TRF: {str(e)}")
        
        return []
    
    def _extract_trf_subject(self, page) -> str:
        """Extrai o assunto do processo TRF"""
        try:
            selectors = ["#classeProcessual", ".classe-processual", ".assunto"]
            for selector in selectors:
                if page.locator(selector).count() > 0:
                    return page.locator(selector).text_content().strip()
            return ""
        except:
            return ""
    
    def _extract_trf_phase(self, page) -> str:
        """Extrai a fase do processo TRF"""
        try:
            selectors = ["#faseProcessual", ".fase-processual", ".fase"]
            for selector in selectors:
                if page.locator(selector).count() > 0:
                    return page.locator(selector).text_content().strip()
            return ""
        except:
            return ""
    
    def _scrape_progress_from_page(self, page, process_number: str, last_update: Optional[datetime]) -> List[ProgressInfo]:
        """Extrai andamentos da página quando API não está disponível"""
        progresses = []
        try:
            # Navegar para página de movimentações
            mov_url = f"{self.base_url}/pje-consulta-api/api/processos/movimentacoes"
            page.goto(mov_url, wait_until='networkidle', timeout=30000)
            
            # Extrair movimentações da tabela
            rows = page.locator("table tbody tr").all()
            
            for row in rows:
                try:
                    cells = row.locator("td").all()
                    if len(cells) >= 2:
                        date_text = cells[0].text_content().strip()
                        desc_text = cells[1].text_content().strip()
                        
                        if date_text and desc_text:
                            try:
                                date = datetime.strptime(date_text, '%d/%m/%Y')
                            except:
                                date = datetime.now()
                            
                            progress = ProgressInfo(
                                date=date,
                                description=desc_text,
                                type=self._classify_progress_type(desc_text),
                                importance=self._classify_importance(desc_text)
                            )
                            
                            progresses.append(progress)
                except:
                    continue
            
            # Filtrar por data
            if last_update:
                progresses = [p for p in progresses if p.date > last_update]
            
        except Exception as e:
            logger.error(f"Erro ao extrair andamentos da página: {str(e)}")
        
        return progresses